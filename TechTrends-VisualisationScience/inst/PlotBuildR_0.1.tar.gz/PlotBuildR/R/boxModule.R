
#' @title RShiny_aggFunc
#' @description The aggFunc creates a function, based on the _operator argument, that accepts a variable name of a data frame as an argument.
#' @family BoxModule
#' @rdname aggFunc
#' @param _operator A character string of the name of an operation that should be performed. Accepts one of the following "Sum", "Mean", "Median", "Count", "Variance", "Standard Deviation", "MAE", "RMSE"
#' @param _var A character string of variable name on which the operation should be performed.
#' @export
aggFunc <- function(`_operator`){
    switch(`_operator`,
           Sum = function(`_var`) sum(`_var`, na.rm = TRUE),
           Mean = function(`_var`) round(mean(`_var`, na.rm = TRUE), 2),
           Median = function(`_var`) round(median(`_var`, na.rm = TRUE), 2),
           Count = function(`_var`) length(`_var`),
           Variance = function(`_var`) round(var(`_var`, na.rm = FALSE), 2),
           `Standard Deviation` = function(`_var`) round(sd(`_var`, na.rm = FALSE), 2),
           MAE = function(`_var`) round(mean(abs(`_var`), na.rm = TRUE), 2),
           RMSE = function(`_var`) round(sqrt(mean(`_var`, na.rm = TRUE)), 2)
    )
}

#' @title RShiny_summariseFunc
#' @description The summariseFunc
#' @family BoxModule
#' @rdname summariseFunc
#' @param df A data frame object
#' @param agg_opr A character string of the name of the aggregation operation that has to be performed. see RShiny_aggFunc
#' @param agg_var Quoted variable name onto which the aggregation will be performed
#' @param ... Quoted and comma-separated column names to group by
#' @import dplyr lazyeval
#' @export
summariseFunc <- function(df, agg_opr, agg_var, ...){
    agg_fun <- aggFunc(agg_opr)

    summariseMetric <- df %>% tbl_df() %>%
        dplyr::group_by_(.dots = c(...)) %>%
        dplyr::summarise_(value = interp(~f(g), f = quote(agg_fun), g = as.name(agg_var))) %>%
        dplyr::rename_(.dots = setNames("value",agg_var)) %>% ungroup()

    return(summariseMetric)
}

#' @title RShiny_generateHistogram
#' @description generateHistogram description
#' @family PlotFunctions
#' @rdname generateHistogram
#' @param plotData add details
#' @param xVar add details
#' @param bins add details
#' @param xTittle add details
#' @param xTickAngle add details
#' @param top add details
#' @param right add details
#' @param bottom add details
#' @param left add details
#' @param alpha add details
#' @export
generateHistogram <- function(`_plotData`, `_xVar`, `_bins`,`_xTitle` = NULL, `_xTickAngle` = 0, `_top` = 100,
                              `_right` = 80, `_bottom` = 80, `_left` = 80, `_alpha` = .8){
    xValue <- genFormula(`_xVar`)

    xBins <- if(`_bins` == 0){
        NULL
    } else {
        list(start = min(`_plotData`[,`_xVar`]), end = max(`_plotData`[,`_xVar`]), size = `_bins`)
    }

    p <- plot_ly(data = `_plotData`, alpha = `_alpha`) %>%
        add_histogram(x = xValue, xbins = xBins) %>%
        layout(xaxis = list(title = ifelse({`_xTitle` == ""|is.null(`_xTitle`)}, `_xVar`, `_xTitle`), tickangle = `_xTickAngle`),
               margin = list(b = `_bottom`, l = `_left`, r = `_right`, t = `_top`))

    return(p)
}

#' @title RShiny_generatePlotUI
#' @description Render a reactive output variable as a plotbuildr within an application page.
#' The output will be included in a box that will contain a plot settings modal, a plot layout settings modal, a plot title as box header components and a plot in the body
#' @family BoxModule
#' @rdname generatePlotUI
#' @param id The `input` slot that will be used to access the value
#' @param col_width width of the column, in which the box will be rendered
#' @param status The status of the item. This determines the item's bachground color. Valid statuses are listed in validStatus(add_link)
#' @param solidHeader Should the header be shown with a solid color background?
#' @import shiny shinydashboard shinyBS
#' @export
generatePlotUI <- function(id, col_width = 12, status = "danger", solidHeader = TRUE){
    ns <- NS(id)
    tagList(
        tags$head(
            includeCSS(file.path(path.package("PlotBuildR"), "www", "styles.css"))
        ),
        box(
            solidHeader = TRUE, status = status, width = col_width,
            title = fluidRow(
                column(
                    width = 4,
                    bsButton(ns("plotSettingsButton"), "", icon = icon("cog", lib = "glyphicon"),
                             size = "extra-small", type = "action",
                             class = "pull-left")
                ),
                column(
                    width = 4,
                    uiOutput(ns("chartTitle"), class="text-center")
                ),
                column(
                    width = 4,
                    bsButton(ns("layoutSettingsButton"), "Layout", icon = icon("cog", lib = "glyphicon"),
                             size = "extra-small", type = "action",
                             class = "pull-right")
                )
            ),
            uiOutput(ns("box"))
        ),
        bsModal(ns("plotSettingsModal"), "Plot Settings", trigger = ns("plotSettingsButton"), plotSettingsUI(ns("plotSettings")), size = "small"),
        bsModal(ns("layoutSettingsModal"), "Layout Settings", trigger = ns("layoutSettingsButton"), layoutSettingsUI(ns("layoutSettings")), size = "small")
    )
}


#' @title RShiny_generatePlot
#' @description The generatePlot function renders a reactive plotbuildr that is suitable for assigning to an output slot
#' @family BoxModule
#' @rdname generatePlot
#' @param input add details
#' @param output add details
#' @param session add details
#' @param reactive_df An unquoted name of a list or a reactiveValues object containing reactive data frames
#' @param df A character string of a data frame object name to plot. Acceptable classes: ; Optional
#' @param links A character string of a data frame object to plot. Optional and used only for the following plot types:
#' @param nodes A character string of a data frame object to plot. Optional and used only for the following plot types:
#' @param x A character string of a column name. Sets the x position. Optional and used only for the following plot types:
#' @param y A character string of a column name. Sets the y position. Optional and used only for the following plot types:
#' @param y2 A character string of a column name. Sets the y2 position. Optional and used only for the following plot types:
#' @param z A character string of a column name. Sets the z position. Optional and used only for the following plot types:
#' @param color A character string of a column name. Sets the marker color. Optional and used only for the following plot types:
#' @param size A character string of a column name. Sets the marker size. Optional and used only for the scatter plot
#' @param value A character string of a column name. Sets the value of the network graph. Looks for the variable inside the `links` data frame. Optional and used only for the plot types
#' @param node_id A character string of a column name. Sets the node_id of the network graph. Looks for the variable inside the `nodes` data frame. Optional and used only for the plot types
#' @param node_group A character string of a column name. Sets the node_group of the network graph. Looks for the variable inside the `nodes` data frame. Optional and used only for the plot types
#' @param plot_type A character string describing the type of trace. For the list of accepted traces see plotChoices
#' @param title A character string describing the title of the plot.
#' @param x_label A character string describing x-axis label.
#' @param y_label A character string describing y-axis label.
#' @import plotly networkD3 dplyr shiny
#' @export
generatePlot <- function(input, output, session, df_list = NULL, reactive_df = NULL, df = NULL, links = NULL, nodes = NULL, x = NULL, y = NULL, y2 = NULL,
                         z = NULL, color = NULL, size = NULL, value = NULL, node_id = NULL, node_group = NULL, plot_type = NULL, title = NULL, x_label = NULL, y_label = NULL){

    plotSettingsList <- callModule(plotSettings, "plotSettings", system_data_list = df_list, user_reactive_data = reactive_df, user_data = df, user_links = links,
                                   user_nodes = nodes, user_x = x, user_y = y, user_y2 = y2, user_z = z, user_color = color, user_size = size,
                                   user_value = value, user_node_id = node_id, user_node_group = node_group, user_plot = plot_type)

    values <- reactive({names(plotSettingsList())})

    selectedPlotType <- reactive({plotSettingsList()$plot})

    layoutSettingsList <- callModule(layoutSettings, "layoutSettings", user_plot = selectedPlotType, user_title = title)

    output$chartTitle <- renderUI({
        tags$strong(layoutSettingsList()$title)
        # if(is.null(title)){
        #     tags$b(layoutSettingsList()$title)
        # } else {
        #     tags$b(title)
        # }
    })

    #output$text1 <- renderText({paste(settingsList()$x, settingsList()$y, settingsList()$color, alpha, sep = ",")})

    #output$text <- renderText({values()})
    output$table <- renderDataTable({
        data <- plotSettingsList()$data
        x <- plotSettingsList()$x
        y <- plotSettingsList()$y
        yAgg <- plotSettingsList()$yAgg
        y2 <- plotSettingsList()$y2
        y2Agg <- plotSettingsList()$y2Agg
        color <- plotSettingsList()$color
        color <- plotSettingsList()$color
        plotType <- plotSettingsList()$plot

        if(plotType %in% "Multiple Bar Plot"){
            full_join(summariseFunc(data, yAgg, y, x), summariseFunc(data, y2Agg, y2, x), by = x)
        } else if(plotType %in% "Bar Plot"){
            summariseFunc(data, yAgg, y, x, color)
        } else if(plotType %in% c("Line Plot", "Area Plot")){
            summariseFunc(data, yAgg, y, x, color)
        } else if(plotType %in% "Scatter Plot"){
            summariseFunc(data, yAgg, y, x, color)

        } else {
            return(NULL)
        }
    },
    options = list(pageLength = 5))

    output$plotly_plot <- renderPlotly({
        data <- plotSettingsList()$data
        x <- plotSettingsList()$x
        y <- plotSettingsList()$y
        z <- plotSettingsList()$z
        yAgg <- plotSettingsList()$yAgg
        y2 <- plotSettingsList()$y2
        y2Agg <- plotSettingsList()$y2Agg
        color <- plotSettingsList()$color
        size <- plotSettingsList()$size
        barMode <- plotSettingsList()$barMode
        barOrientation <- plotSettingsList()$barOrientation
        histoBins <- plotSettingsList()$bins
        hole <- plotSettingsList()$donutSize
        plotType <- plotSettingsList()$plot
        xTitle <- layoutSettingsList()$xTitle
        xTitle <- if(!is.null(x_label) && xTitle == "") {x_label} else { xTitle }
        yTitle <- layoutSettingsList()$yTitle
        yTitle <- if(!is.null(y_label) && yTitle == "") {y_label} else { yTitle }
        xTickAngle <- layoutSettingsList()$xTickAngle
        yTickAngle <- layoutSettingsList()$yTickAngle
        t <- layoutSettingsList()$t
        r <- layoutSettingsList()$r
        b <- layoutSettingsList()$b
        l <- layoutSettingsList()$l
        legendOrientation <- layoutSettingsList()$legendO

        if(plotType %in% "Multiple Bar Plot"){

            full_join(summariseFunc(data, yAgg, y, x), summariseFunc(data, y2Agg, y2, x), by = x) %>%
                generateMBarPlot(x, y, y2, xTitle, yTitle, xTickAngle, yTickAngle, t, r, b, l, legendOrientation)

        } else if(plotType %in% "Bar Plot"){

            summariseFunc(data, yAgg, y, x, color) %>%
                generateBarPlot(x, y, color, barMode, barOrientation, xTitle, yTitle, xTickAngle, yTickAngle, t, r, b, l, legendOrientation)

        } else if(plotType %in% "Scatter Plot"){

            summariseFunc(data, yAgg, y, x, color, size) %>%
                generateScatterPlot(x, y, color, size, xTitle, yTitle, xTickAngle, yTickAngle, t, r, b, l, legendOrientation)

        } else if(plotType %in% "Multiple Line Plot"){

            full_join(summariseFunc(data, yAgg, y, x), summariseFunc(data, y2Agg, y2, x), by = x) %>%
                generateMLinePlot(x, y, y2, xTitle, yTitle, xTickAngle, yTickAngle, t, r, b, l, legendOrientation)

        } else if(plotType %in% "Line Plot"){

            summariseFunc(data, yAgg, y, x, color) %>%
                generateLinePlot(x, y, color, xTitle, yTitle, xTickAngle, yTickAngle, t, r, b, l, legendOrientation)

        } else if(plotType %in% "Area Plot"){

            summariseFunc(data, yAgg, y, x, color) %>%
                generateAreaPlot(x, y, color, xTitle, yTitle, xTickAngle, yTickAngle, t, r, b, l, legendOrientation)

        } else if(plotType %in% "Histogram"){

            generateHistogram(data, x, histoBins, xTitle, xTickAngle, t, r, b, l, legendOrientation)

        } else if(plotType %in% "Box Plot"){

            generateBoxPlot(data, x, y, color, xTitle, yTitle, xTickAngle, yTickAngle, t, r, b, l, legendOrientation)

        } else if(plotType %in% "Pie Chart"){
            summariseFunc(data, yAgg, y, x) %>%
                generatePieChart(x, y, hole, t, r, b, l, legendOrientation)

        } else if(plotType %in% "Contour Plot"){

            generateContourPlot(data, x, y, z, xTitle, yTitle, xTickAngle, yTickAngle, t, r, b, l, legendOrientation)

        } else if(plotType %in% "Heatmap"){

            generateHeatmap(data, x, y, z, xTitle, yTitle, xTickAngle, yTickAngle, t, r, b, l, legendOrientation)

        } else {
            return(NULL)
        }
    })

    output$simple_network <- renderSimpleNetwork({
        data <- plotSettingsList()$data
        x <- plotSettingsList()$x
        y <- plotSettingsList()$y
        generateSimpleNetwork(data, x, y)
    })

    output$force_network <- renderForceNetwork({
        links <- plotSettingsList()$data[[1]]
        nodes <- plotSettingsList()$data[[2]]
        link_source <- plotSettingsList()$x
        link_target <- plotSettingsList()$y
        link_value <- plotSettingsList()$networkValue
        nodeId <- plotSettingsList()$nodeId
        node_group <- plotSettingsList()$nodeGroup
        generateForceNetwork(links, nodes, link_source, link_target, link_value, nodeId, node_group)
    })

    output$sankey_network <- renderSankeyNetwork({
        links <- plotSettingsList()$data[[1]]
        nodes <- plotSettingsList()$data[[2]]
        link_source <- plotSettingsList()$x
        link_target <- plotSettingsList()$y
        link_value <- plotSettingsList()$networkValue
        nodeId <- plotSettingsList()$nodeId
        generateSankeyNetwork(links, nodes, link_source, link_target, link_value, nodeId)
    })

    output$dendro_network <- renderSimpleNetwork({
        data <- plotSettingsList()$data
        x <- plotSettingsList()$x
        y <- plotSettingsList()$y
        generateSimpleNetwork(data, x, y)
    })

    output$box <- renderUI({
        ns <- session$ns

        plotType <- plotSettingsList()$plot
        print("inside the box")
        tagList(
            #verbatimTextOutput(ns("text")),
            if(plotType == "Simple Network"){
                simpleNetworkOutput(ns("simple_network"))
            } else if(plotType == "Force Network"){
                forceNetworkOutput(ns("force_network"))
            } else if(plotType == "Sankey Network"){
                sankeyNetworkOutput(ns("sankey_network"))
            } else if(plotType == "Dendro Network"){
                dendroNetworkOutput(ns("dendro_network"))
            } else {
                plotlyOutput(ns("plotly_plot"))
            }
            #dataTableOutput(ns("table"))
        )
    })

    # xValue <- reactive({
    #     settingsList()$xValue
    # })
    #
    # yValue <- reactive({
    #     settingsList()$yValue
    # })
    #
    # zValue <- reactive({
    #     settingsList()$zValue
    # })
    #
    # yAgg <- reactive({
    #     settingsList()$yAgg
    # })
    #
    # colorGroup <- reactive({
    #     settingsList()$colorGroup
    # })
    #
    # sizeGroup <- reactive({
    #     settingsList()$sizeGroup
    # })
    #
    # plotType <- reactive({
    #     settingsList()$plotType
    # })
    #
    # plotMode <- reactive({
    #     settingsList()$plotMode
    # })
    #
    # agg_metric <- reactive({
    #     aggMetricFunc(yAgg, yValue)
    # })

    # output$text2 <- renderText({agg_metric()})
    #
    # output$table2 <- renderDataTable({
    #     if(xValue() == colorGroup()){
    #     aggFuncXvalColSame(data, xValue, yValue, agg_metric)
    # } else {
    #     aggFuncXvalColDiff(data, xValue, yValue, colorGroup, agg_metric)
    # }
    # })

    # plot_data <- reactive({
    #     validate(need(settingsList(), FALSE))
    #     if(xValue() == colorGroup()) {
    #         df_plot <- aggFuncXvalColSame(data, xValue, yValue, agg_metric)
    #         # df_plot <- data() %>%
    #         #     dplyr::group_by_(xValue()) %>%
    #         #     dplyr::summarise_(value= agg_metric()) %>%
    #         #     dplyr::rename_(.dots = setNames("value", yValue())) %>% ungroup()
    #     } else if(xValue() == sizeGroup()){
    #
    #     } else {
    #         df_plot <- aggFuncXvalColDiff(data, xValue, yValue, colorGroup, agg_metric)
    #         # df_plot <- data() %>%
    #         #     dplyr::group_by_(xValue(), colorGroup()) %>%
    #         #     dplyr::summarise_(value= agg_metric()) %>%
    #         #     dplyr::rename_(.dots = setNames(list())) %>% ungroup()
    #     }
    #     df_plot
    # })

    # output$table2 <- renderDataTable({
    #     plot_data()
    # })
    #output$text3 <- renderText({paste(xValue(), yValue(), colorGroup(), plotMode(), agg_metric(), sep = ",")})
    #output$table3 <- renderDataTable({data()})
    # output$Chart <- renderPlotly({
    #     validate(need(list(settingsList(), agg_metric()), FALSE))
    #     #This should be a function in the future. One function per plot type
    #     switch(plotType(),
    #            "Area Plot" = {
    #                p <- generateAreaPlot(data, xValue, yValue, colorGroup, agg_metric, alpha = alpha)
    #                if(is.null(p)){
    #                    # createAlert(session, "alert", "exampleAlert", title = "Oops",
    #                    #             content = "Both inputs should be numeric.")
    #                }else{
    #                    #closeAlert(session, "exampleAlert")
    #                    return(p)
    #                }
    #            },
    #            "Bar Plot" = {
    #                p <- generateBarPlot(data, xValue, yValue, colorGroup, plotMode, agg_metric, alpha = alpha)
    #            },
    #            "Scatter Plot" = {
    #                p <- generateScatterPlot(data, xValue, yValue, colorGroup, sizeGroup, agg_metric, alpha = alpha)
    #            },
    #            "Line Plot" = {
    #                p <- generateLinePlot(data, xValue, yValue, colorGroup, agg_metric, alpha = alpha)
    #            },
    #            "Histogram" = {
    #                p <- generateHistogram(data, xValue, alpha = alpha)
    #            },
    #            "Box Plot" = {
    #                p <- generateBoxPlot(data, xValue, yValue, colorGroup, agg_metric, alpha = alpha)
    #            },
    #            "Contour Plot" = {
    #                p <- generateContourPlot(data, xValue, yValue, zValue, yAgg, alpha = alpha)
    #            },
    #            "Heatmap" = {
    #                p <- generateContourPlot(data, xValue, yValue, zValue, yAgg, alpha = alpha)
    #            },
    #            "Pie Chart" = {
    #                p <- generatePieChart(data, xValue, yValue, agg_metric, alpha = alpha)
    #            })
    #     return(p)
    # })
}
