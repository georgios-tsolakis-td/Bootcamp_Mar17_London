
#' @title RShiny_list_to_df
#' @description The list_to_df function takes the named list and converts it into a tibble
#' @family PlotSettingsModule
#' @rdname list_to_df
#' @param x A named list
#' @param key A character string defining the column name for the name of each item in the list
#' @param value A character string defining the column name for the elements of each item in the list
#' @import dplyr tidyr
#' @export
list_to_df <- function(x, `_key`, `_value`){
    temp_df <- sapply(x, '[', seq(max(sapply(x,length)))) %>% tbl_df %>%
        tidyr::gather_(key_col = `_key`, value_col = `_value`, gather_cols = names(.), na.rm = TRUE)

    return(temp_df)
}

#' @title RShiny_standardBootstrapPage
#' @description A standardBootstrapPage is a shiny UI panel that has two equal-widthed inline selectInput objects. The width is set proportional to a small bsModal
#' @family PlotSettingsModule
#' @rdname standardBootstrapPage
#' @param input1_id An id for the first selectInput object. To be passed inside a namespaced function. Eg. ns("input1ID")
#' @param input1_label A character string describing the first selectInput object. Defaults to NULL
#' @param input1_choices A list of values to select from the first selectInput object. Defaults to NULL
#' @param input2_id An id for the second selectInput object. To be passed inside a namespaced function. Eg. ns("input2ID")
#' @param input2_label A character string describing the second selectInput object. Defaults to NULL
#' @param input2_choices A list of values to select from the second selectInput object. Defaults to NULL
#' @param theme select a bootstrap theme. see shinythemes
#' @import shiny shinythemes
#' @export
standardBootstrapPage <- function(input1_id, input1_label = NULL, input1_choices = NULL, input2_id, input2_label = NULL, input2_choices = NULL, theme ){
    bootstrapStyle <- "display:inline-block; font-size:14px;"
    bootstrapPage(theme = shinythemes::shinytheme(theme = theme),
                  div(style= bootstrapStyle,
                      shiny::selectInput(input1_id, label = input1_label, choices = input1_choices, width = "125px")
                  ),
                  div(style= bootstrapStyle,
                      shiny::selectInput(input2_id, label = input2_label, choices = input2_choices, width = "125px"))
    )
}

#' @title RShiny_bootstrapPageWithModal
#' @description bootstrapPageWithModal description
#' @family PlotSettingsModule
#' @rdname bootstrapPageWithModal
#' @param value_id An id for the first selectInput object. To be passed inside a namespaced function. Eg. `ns("valueID")`
#' @param button_id An id for the bsButton object. To be passed inside a namespaced function. Eg. `ns("bsButtonID")`
#' @param modal_id An id for the bsModal object. To be passed inside a namespaced function. Eg. `ns("modalID")`
#' @param settings_id An id for the second selectInput object. To be passed inside a namespaced function. Eg. `ns("settingsID")`
#' @param modal_title A character string to describe the bsModal
#' @param select_input_choices A list of values to select from the second selectInput object. Defaults to NULL
#' @param size size of the bsModal. Values accepted "small", "medium" and "large"
#' @param theme select a bootstrap theme. see shinythemes
#' @param button_style A Bootstrap style to apply to the button. (default, primary, success, info, warning, or danger)
#' @param button_icon An optional icon to appear on the button.
#' @param button_size The size of the button (extra-small, small, default, or large)
#' @param selected_input_choices The initially selected value of the second selectInput object
#' @import shiny shinyBS shinythemes
#' @export
bootstrapPageWithModal <- function(value_id, button_id, modal_id, settings_id, modal_title = NULL, select_input_choices = NULL,
                                   size, theme, button_style = "primary", button_icon = NULL, button_size = "default", selected_input_choices = NULL){
    bootstrapStyle <- "display:inline-block; font-size:14px;"
    bootstrapPage(theme = shinythemes::shinytheme(theme = theme),
                  div(style = bootstrapStyle,
                      shiny::selectInput(value_id, label = "", choices = NULL, width = "190px")
                  ),
                  div(style = bootstrapStyle,
                      shinyBS::bsButton(inputId = button_id, label = "", type = "action", style = button_style, icon = button_icon, size = button_size)
                  ),
                  shinyBS::bsModal(modal_id, title = modal_title, trigger = button_id, size = "small",
                                   shiny::selectInput(settings_id, label = NULL, choices = select_input_choices, selectize = FALSE, size = size, selected = selected_input_choices)
                  )
    )
}

#' @title RShiny_aggregationButtonLabel
#' @description The aggregationButtonLabel function creates a label for the bsButton used in the bootstrapPageWithModal
#' @family PlotSettingsModule
#' @rdname aggregationButtonLabel
#' @param st A character string. Accepted values are one of the aggChoices values
#' @export
aggregationButtonLabel <- function(st){
    label = NULL
    switch(st,
           "Count" = {
               label = "CNT"
           },
           "Mean" = {
               label = "MEAN"
           },
           "Median" = {
               label = "MDN"
           },
           "Sum" = {
               label = "SUM"
           },
           "Max" = {
               label = "MAX"
           },
           "Min" = {
               label = "MIN"
           },
           "MAE" = {
               label = "MAE"
           },
           "RMSE" = {
               label = "RMSE"
           },
           "Variance" = {
               label = "VAR"
           },
           "Standard Deviation" = {
               label = "SD"
           })
    return(label)
}

#' @title RShiny_dataChoicesFunc
#' @description A list containing the dataChoices loaded in R memory, a data frame containing the names of data frames loaded and their classes,
#' a character vector with the type of accepted classes and a character vector containing names of data frames to be excluded
#' @family PlotSettingsModule
#' @rdname dataChoicesFunc
#' @param fileNames ls() = list of all the data frames loaded in R memory
#' @param acceptedClasses A character vector containing type of accepted classes
#' @param excludedFiles A character vector containing the names of excluded data frames
#' @import dplyr
#' @export
dataChoicesFunc<-function(
    fileNames = NULL,
    acceptedClasses=c("data.frame", "tbl_df", "data.table", "tbl_dt", "grouped_df", "grouped_dt"),
    excludedFiles=c("grid", "loadedFiles", "aggChoicesDF", "plotChoicesDF", "filePaths")
){
    fileNames <- fileNames
    loadedFiles <-  ldply(fileNames, .fun = function(x){class(get(x))[1]}) %>% dplyr::tbl_df() %>%
        dplyr::mutate(`.id` = fileNames) %>% dplyr::select(`.id`, class = V1)

    acceptedClasses <- acceptedClasses
    excludedFiles <- excludedFiles

    returnList <- list(
        loadedFiles = loadedFiles,
        acceptedClasses = acceptedClasses,
        excludedFiles = excludedFiles)
    return(returnList)
}

#' @title RShiny_plotChoices
#' @description plotChoices description
#' @family PlotSettingsModule
#' @rdname plotChoices
#' @param plotChoices_list A named list of all the plot choices
#' @export
plotChoices <- function(plotChoices_list = list("Classic Plots" = c("Multiple Bar Plot","Bar Plot", "Scatter Plot","Multiple Line Plot" ,"Line Plot", "Area Plot"),
                                                "Statistical Plots" = c("Histogram", "Box Plot", "Pie Chart"),
                                                "3D Plots" = c("Heatmap", "Contour Plot"),
                                                "Network Graphs" = c("Simple Network", "Force Network", "Sankey Network", "Dendro Network"))){
    returnList <- list()
    returnList$plotChoices_list <- plotChoices_list
    returnList$plotChoices_tbl <- list_to_df(plotChoices_list, "Category", "Type")

    return(returnList)
}

#' @title RShiny_aggChoices
#' @description aggChoices description
#' @family PlotSettingsModule
#' @rdname aggChoices
#' @param aggChoices_list A named list of all the aggregation choices
#' @export
aggChoices <- function(
    aggChoices_list = list("Operations" = c("Count", "Mean", "Median", "Sum"),
                           "Statistics" = c("Variance", "Standard Deviation"),
                           #"Transformation" = c("Exponential", "Log", "Square", "Square Root"),
                           "Error" = c("MAE", "RMSE"))){

    returnList <- list(aggChoices_list = NULL, aggChoices_tbl = NULL)
    returnList$aggChoices_list <- aggChoices_list
    returnList$aggChoices_tbl <- list_to_df(aggChoices_list, "AggregationCategory", "AggregationType")

    return(returnList)
}

# Polar Chart   color, mode, y-aggregation
# Surface Plot
# Simple Network	linkDistance, charge
# Force Network	    opacity, nodeSize, linkDistance, charge
# Sankey Network	LinkGroup

#' @title RShiny_plotSettingsUI
#' @description The plotSettingsUI creates a UI frame to get various plot settings input values from the user.
#' It is passed in a bsModal which is accessed when the user clicks the plot settings button placed at the header of the plot box
#' @family PlotSettingsModule
#' @rdname plotSettingsUI
#' @param id The id string that will be used to access the values
#' @param user_theme select a bootstrap theme. see shinythemes
#' @import shiny
#' @export
plotSettingsUI <- function(id, user_theme="united"){
    ns <- shiny::NS(id)
    bootstrapStyle <- "display:inline-block; font-size:14px;"

    shiny::tabsetPanel(

        shiny::tabPanel("Plot Type",
                 includeCSS(file.path(path.package("PlotBuildR"), "www", "gallery.css")),
                 selectInput(ns("plotType"), label = "Plot Type", choices = NULL), #Plot Type UI ####
                 includeScript(file.path(path.package("PlotBuildR"), "www", "gallery.js"))

        ),
        shiny::tabPanel("Settings",

                        shiny::tagList(

                            shiny::conditionalPanel( # Dataset UI####
                                                     condition = sprintf("input['%s'] != 'Force Network' &
                                                input['%s'] != 'Sankey Network'",
                                                                         ns("plotType"), ns("plotType")),
                                                     selectInput(ns("dataSet"), label = "Dataset Choices", choices = NULL)
                            ),
                            shiny::conditionalPanel( # Link & Node UI ####
                                                     condition = sprintf("input['%s'] == 'Force Network'|
                                    input['%s'] == 'Sankey Network'",
                                                                         ns("plotType"), ns("plotType")),
                                                     standardBootstrapPage(input1_id = ns("Links"), input1_label = "Links", input2_id = ns("Nodes"), input2_label = "Nodes", theme = user_theme)
                            ),
                            shiny::conditionalPanel(# X Value UI ####
                                                    condition = sprintf("input['%s'] != 'Dendro Network'", ns("plotType")),
                                                    bootstrapPageWithModal(value_id = ns("xValue"), button_id = ns("xSettingsButton"), modal_id = ns("xSettingsModal"),
                                                                           settings_id =  ns("xSettings"), size = 2, theme = user_theme)
                            ),
                            shiny::conditionalPanel(# Y Value UI ####
                                                    condition = sprintf("input['%s'] != `Histogram` &
                                    input['%s'] != 'Dendro Network'",
                                                                        ns("plotType"), ns("plotType")),
                                                    bootstrapPageWithModal(value_id = ns("yValue"), button_id = ns("yAggButton"), modal_id = ns("yAggModal"),
                                                                           settings_id =  ns("yAggregation"), select_input_choices = aggChoices()[[1]], size = 11, theme = user_theme, selected_input_choices = "Mean")

                            ),
                            shiny::conditionalPanel( # Y2 Value UI ####
                                                     condition = sprintf("input['%s'] == 'Multiple Line Plot' |
                                    input['%s'] == 'Multiple Bar Plot'",
                                                                         ns("plotType"), ns("plotType")),
                                                     bootstrapPageWithModal(value_id = ns("y2Value"), button_id = ns("y2AggButton"), modal_id = ns("y2AggModal"),
                                                                            settings_id =  ns("y2Aggregation"), select_input_choices = aggChoices()[[1]], size = 11, theme = user_theme, selected_input_choices = "Mean")
                            ),
                            shiny::conditionalPanel(# Dendro Add-on ####
                                                    condition = sprintf("input['%s'] == 'Dendro Network'", ns("plotType")),
                                                    standardBootstrapPage(input1_id = ns("linkType"), input1_label = "Link Type", input1_choices = c("Elbow", "Diagonal"),
                                                                          input2_id = ns("treeOrientation"), input2_label = "Tree Orientation", input2_choices = c("vertical", "horizontal"), theme = user_theme)
                            ),
                            shiny::conditionalPanel(# Z Value UI ####
                                                    condition = sprintf("input['%s'] == `Heatmap` |
                                        input['%s'] == 'Contour Plot' |
                                        input['%s'] == 'Surface Plot'",
                                                                        ns("plotType"), ns("plotType"), ns("plotType")),
                                                    bootstrapPageWithModal(value_id = ns("zValue"), button_id = ns("zAggButton"), modal_id = ns("zAggModal"),
                                                                           settings_id =  ns("zAggregation"), select_input_choices = aggChoices()[[1]], size = 11, theme = user_theme, selected_input_choices = "Mean")
                            ),
                            shiny::conditionalPanel(# Histogram Add-on ####
                                                    condition = sprintf("input['%s'] == `Histogram`", ns("plotType")),
                                                    sliderInput(ns("histoBins"), label = "# of Bins", min = 1, max = 100, value = 10, width = "250px")
                            ),
                            shiny::conditionalPanel(# Color Group UI ####
                                                    condition = sprintf("input['%s'] == 'Bar Plot' |
                                    input['%s'] == 'Line Plot' |
                                    input['%s'] == 'Area Plot' |
                                    input['%s'] == 'Scatter Plot' |
                                    input['%s'] == 'Box Plot' |
                                    input['%s'] == 'Polar Chart'",
                                                                        ns("plotType"), ns("plotType"), ns("plotType"),
                                                                        ns("plotType"), ns("plotType"), ns("plotType")),
                                                    bootstrapPageWithModal(value_id = ns("colorGroup"), button_id = ns("colorButton"), modal_id = ns("colorModal"),
                                                                           settings_id = ns("colorPalette"), size = 7, theme = user_theme, button_icon = icon("paint-brush"), button_size = "small",
                                                                           select_input_choices = c("Set 1", "Set 2", "Set 3", "BrBG", "RdYlBu", "RdYlGn", "Spectral"))
                            ),
                            shiny::conditionalPanel(# Donut size of piechart
                                condition = sprintf("input['%s'] == 'Pie Chart'", ns("plotType")),
                                sliderInput(ns("donutSize"), "Size of Donut", min = 0, max = .9, value = 0.3, step = .1, width = "150px")
                            ),
                            shiny::conditionalPanel( # Bar Plot Add-ons
                                condition = sprintf("input['%s'] == 'Bar Plot'", ns("plotType")),
                                standardBootstrapPage(ns("barMode"), "Mode", c("group", "stack"), ns("barOrientation"), "Orientation", c("v", "h"), theme = user_theme)
                            ),
                            shiny::conditionalPanel(
                                condition = sprintf("input['%s'] == 'Scatter Plot'", ns("plotType")),
                                selectInput(ns("sizeGroup"), "Size", choices = NULL, width = "125px")
                            ),
                            shiny::conditionalPanel(# Force & Sankey network add-ons
                                condition = sprintf("input['%s'] == 'Force Network' |
                                                input['%s'] == 'Sankey Network'",
                                             ns("plotType"), ns("plotType")),
                         bootstrapPageWithModal(value_id = ns("networkValue"), button_id = ns("networkButton"), modal_id = ns("networkModal"),
                                                settings_id =  ns("networkSettings"), size = 2, theme = user_theme),
                         standardBootstrapPage(input1_id = ns("nodeId"), input1_label = "Node Id", input2_id = ns("nodeGroup"), input2_label = "Group", theme = user_theme)
                     )
                 )
        )
    )

}

#' @title RShiny_plotSettings
#' @description The plotSettings function returns a list of user defined inputs related to plot settings. The function is called inside generatePlot function
#' @family PlotSettingsModule
#' @rdname plotSettings
#' @param input add details
#' @param output add details
#' @param session add details
#' @param user_reactive_data An unquoted name of a list or a reactiveValues object containing reactive data frames
#' @param user_data A character string of a data frame object name to plot. Acceptable classes: ; Optional
#' @param user_links A character string of a data frame object to plot. Optional and used only for the following plot types:
#' @param user_nodes A character string of a data frame object to plot. Optional and used only for the following plot types:
#' @param user_x A character string of a column name. Sets the x position. Optional and used only for the following plot types:
#' @param user_y A character string of a column name. Sets the y position. Optional and used only for the following plot types:
#' @param user_y2 A character string of a column name. Sets the y2 position. Optional and used only for the following plot types:
#' @param user_z A character string of a column name. Sets the z position. Optional and used only for the following plot types:
#' @param user_color A character string of a column name. Sets the marker color. Optional and used only for the following plot types:
#' @param user_size A character string of a column name. Sets the marker size. Optional and used only for the scatter plot
#' @param user_value A character string of a column name. Sets the value of the network graph. Looks for the variable inside the `links` data frame. Optional and used only for the plot types
#' @param user_node_id A character string of a column name. Sets the node_id of the network graph. Looks for the variable inside the `nodes` data frame. Optional and used only for the plot types
#' @param user_node_group A character string of a column name. Sets the node_group of the network graph. Looks for the variable inside the `nodes` data frame. Optional and used only for the plot types
#' @param user_plot A character string describing the type of trace. For the list of accepted traces see plotChoices
#' @import dplyr shiny
#' @export
plotSettings <- function(input, output, session, system_data_list = NULL, user_reactive_data = NULL, user_data = NULL, user_links = NULL, user_nodes = NULL, user_x = NULL,
                         user_y = NULL, user_y2 = NULL, user_z = NULL, user_color = NULL, user_size = NULL, user_value = NULL,
                         user_node_id = NULL, user_node_group = NULL, user_plot = NULL) {
    ns <- session$ns
    # Plot Type Update ####

    pc_list <- plotChoices()[[1]]
    pc_tbl <- plotChoices()[[2]]

    observe({
        cond <- is.null(user_plot)
        selected <- ifelse(cond,
                           pc_tbl[ceiling(runif(1, 0, nrow(pc_tbl))), 2] %>% unlist(use.names = F),
                           user_plot)
        shiny::updateSelectInput(session, "plotType", choices = pc_list, selected = selected)
    })

    # Data Set Update ####

    reactiveLoadedFiles <- reactive({
        if(!is.null(user_reactive_data)){
            ldply(user_reactive_data, .fun = function(x){class(x())[1]}) %>% tbl_df %>%
                dplyr::rename(class = V1)
        } else {
            NULL
        }
    })

    # Extracting values from dataChoices function
    dc <- dataChoicesFunc(fileNames = system_data_list)
    loadedFiles <- dc$loadedFiles
    excludedFiles <- dc$excludedFiles
    acceptedClasses <- dc$acceptedClasses

    dataChoices <- reactive({

        temp <- dplyr::filter(loadedFiles, !(`.id` %in% excludedFiles))

        temp2 <- if(!is.null(reactiveLoadedFiles())){
            union(temp, reactiveLoadedFiles()) %>%
                dplyr::arrange(`.id`)
        } else{
            temp
        }

        temp3 <- if(shiny::req(input$plotType) == "Dendro Network"){
            dplyr::filter(temp2, class == "hclust")
        } else if(input$plotType == "Time Series"){
            dplyr::filter(temp2, class %in% c("mts", "ts", "xts"))
        } else{
            dplyr::filter(temp2, class %in% acceptedClasses)
        }
        temp4 <- temp3 %>% dplyr::select(`.id`) %>% unlist(use.names = FALSE)

        return(temp4)
    })

    observe({
        if(is.null(user_data)){
            shiny::updateSelectInput(session, "dataSet", choices = dataChoices(), selected = dataChoices()[ceiling(runif(1, 1, length(dataChoices())))])
        } else {
            shiny::updateSelectInput(session, "dataSet", choices = dataChoices(), selected = user_data)
        }
    })

    observe({
        if(is.null(user_links)){
            shiny::updateSelectInput(session, "Links", choices = dataChoices(), selected = dataChoices()[ceiling(runif(1, 1, length(dataChoices())))])
        }else{
            shiny::updateSelectInput(session, "Links", choices = dataChoices(), selected = user_links)
        }
    })

    observe({
        if(is.null(user_nodes)){
            shiny::updateSelectInput(session, "Nodes", choices = dataChoices(), selected = dataChoices()[ceiling(runif(1, 1, length(dataChoices())))])
        }else{
            shiny::updateSelectInput(session, "Nodes", choices = dataChoices(), selected = user_nodes)
        }
    })

    data <- reactive({
        validate(need(input$dataSet, FALSE))

        if(input$dataSet %in% names(user_reactive_data)){
            if(shiny::req(input$plotType) %in% c("Force Network", "Sankey Network")){
                list("Links" = user_reactive_data[[input$Links]](), "Nodes" = user_reactive_data[[input$Nodes]]())
            }else {
                user_reactive_data[[input$dataSet]]()
            }
        } else {
            if(shiny::req(input$plotType) %in% c("Force Network", "Sankey Network")){
                list("Links" = get(input$Links), "Nodes" = get(input$Nodes))
            }else {
                get(input$dataSet)
            }
        }
    })

    # get column classes
    colClass <- reactive({
        if(shiny::req(input$plotType) %in% c("Force Network", "Sankey Network")){
            sapply(data()$Links, function(x){class(x)[1]})
        }else{
            sapply(data(), function(x){class(x)[1]})
        }
    })

    # X Value Update ####
    xInputLabel <- reactive({
        if(shiny::req(input$plotType) %in% c("Simple Network", "Force Network", "Sankey Network")){
            "Source"
        }else if(input$plotType == "Pie Chart"){
            "Labels"
        }else{
            "X-Axis"
        }
    })

    xChoices <- reactive({
        temp <- if(shiny::req(input$plotType) %in% c("Pie Chart", "Box Plot")){
            names(colClass()[grepl("character|factor|logical|ordered", colClass())])
        } else if(input$plotType %in% c("Force Network", "Sankey Network")){
            names(colClass()[grepl("integer", colClass())])
        } else if(input$plotType == "Contour Plot"){
            names(colClass()[grepl("integer|numeric", colClass())])
        } else {
            names(colClass())
        }
        temp <- temp[order(temp)]
    })

    observe({
        validate(need(list(input$plotType, input$dataSet), FALSE))
        if({is.null(user_data)|is.null(user_x)}){
            shiny::updateSelectInput(session, "xValue", label = xInputLabel(), choices = xChoices(), selected = xChoices()[1])
        } else {
            shiny::updateSelectInput(session, "xValue", label = xInputLabel(), choices = xChoices(), selected = user_x)
        }
    })

    # X Settings Update ####

    xSelectedClass <- reactive({
        shiny::req(input$xValue)
        colNames <- if(input$plotType %in% c("Force Network", "Sankey Network")){
            names(data()$Links)
        } else{
            names(data())
        }
        data.frame("ColNames" = colNames, "Class" = colClass()) %>%
            dplyr::filter(ColNames %in% input$xValue) %>% dplyr::select(Class) %>% unlist(use.names = FALSE)
    })

    xSettingsChoices <- reactive({
        shiny::validate(need(xSelectedClass(), FALSE))

        x <- if(xSelectedClass() %in% c("integer", "numeric")){
            c("As Number", "As Factor")
        } else {
            xSelectedClass()
        }
        return(x)
    })

    observe({
        shiny::updateSelectInput(session, "xSettings", label = NULL, choices = xSettingsChoices(), selected = xSettingsChoices()[1])
    })

    # X Settings Button Label Update ####

    observeEvent({
        shiny::req(input$xSettings)
        input$plotType},{

            st <- input$xSettings
            pt <- input$plotType

            disabled = NULL
            label = NULL

            if(pt %in% c("Force Network", "Sankey Network")){
                disabled = TRUE
                label = "INT"
            } else if(pt == "Contour Plot"){
                disabled = TRUE
                label = "NUM"
            } else if(pt %in% c("Heatmap", "Simple Network")){
                disabled = TRUE
                label = "---"
            } else {
                switch(st,
                       "As Number" = {
                           disabled = FALSE
                           label = "NUM"
                       },
                       "As Factor" = {
                           disabled = FALSE
                           label = "FCT"
                       },
                       "character" = {
                           disabled = TRUE
                           label = "CHR"
                       },
                       "factor" = {
                           disabled = TRUE
                           label = "FCT"
                       },
                       "ts" = {
                           disabled = TRUE
                           label = "TS"
                       },
                       "logical" = {
                           disabled = TRUE
                           label = "LOG"
                       })
            }

            shinyBS::updateButton(session, ns("xSettingsButton"), label = label, disabled = disabled, size = "small")
        })

    # Y Value Update ####

    yInputLabel <- reactive({
        if(shiny::req(input$plotType) %in% c("Simple Network", "Force Network", "Sankey Network")){
            "Target"
        }else if(input$plotType == "Pie Chart"){
            "Value"
        }else{
            "Y-Axis"
        }
    })

    yChoices <- reactive({
        shiny::req(input$xValue)
        temp <- if(shiny::req(input$plotType) %in% c("Heatmap", "Simple Network")){
            names(data())
        } else if(input$plotType %in% c("Force Network", "Sankey Network")){
            names(colClass()[grepl("integer", colClass())])
        } else{
            names(colClass()[grepl("numeric|integer|ts", colClass())])
        }
        temp <- temp[order(temp)]
        temp <- temp[!grepl(input$xValue,temp)]
    })

    observe({
        shiny::validate(need(list(input$plotType, input$dataSet), FALSE))
        if({is.null(user_data)|is.null(user_y)}){
            shiny::updateSelectInput(session, "yValue", label = yInputLabel(), choices = yChoices(), selected = yChoices()[1])
        } else {
            shiny::updateSelectInput(session, "yValue", label = yInputLabel(), choices = yChoices(), selected = user_y)
        }
    })

    # Y Aggregation Button Label Update ####

    observeEvent({
        shiny::req(input$yAggregation)
        shiny::req(input$plotType)},{

            st <- input$yAggregation
            pt <- input$plotType

            disabled = NULL
            label = NULL

            if(pt %in% c("Heatmap", "Simple Network")){
                disabled = TRUE
                label = "---"
            }else if(pt == "Contour Plot"){
                disabled = TRUE
                label = "NUM"
            } else if(pt %in% c("Force Network", "Sankey Network")){
                disabled = TRUE
                label = "INT"
            } else{
                disabled = FALSE
                label = aggregationButtonLabel(st)
            }

            shinyBS::updateButton(session, ns("yAggButton"), label = label, disabled = disabled, size = "small")
        })

    # Y 2 Value Update ####

    y2Choices <- reactive({
        shiny::req(input$xValue)
        temp <- names(colClass()[grepl("numeric|integer", colClass())])
        temp <- temp[order(temp)]
        temp <- temp[!grepl(paste(input$xValue, input$yValue, sep = "|"),temp)]
    })

    observe({
        shiny::validate(need(list(input$plotType, input$dataSet), FALSE))
        if({is.null(user_data)|is.null(user_y2)}){
            shiny::updateSelectInput(session, "y2Value", label = "Y2-Axis", choices = y2Choices(), selected = y2Choices()[1])
        } else {
            shiny::updateSelectInput(session, "y2Value", label = yInputLabel(), choices = yChoices(), selected = user_y2)
        }
    })

    # Y2 Aggregation Button Label Update ####

    observeEvent(shiny::req(input$y2Aggregation),{

        st <- input$y2Aggregation

        label = aggregationButtonLabel(st)

        shinyBS::updateButton(session, ns("y2AggButton"), label = label, size = "small")
    })

    # Z Value Update ####

    zChoices <- reactive({
        shiny::req(input$yValue, input$xValue)
        temp <- names(colClass()[grepl("numeric|integer", colClass())])
        temp <- temp[!grepl(paste(input$xValue, input$yValue, sep = "|"), temp)]
        temp <- temp[order(temp)]
    })

    observe({
        shiny::validate(need(list(input$plotType, input$dataSet), FALSE))
        if({is.null(user_data)|is.null(user_z)}){
            shiny::updateSelectInput(session, "zValue", label = "Z-Axis", choices = zChoices(), selected = zChoices()[1])
        } else {
            shiny::updateSelectInput(session, "zValue", label = "Z-Axis", choices = zChoices(), selected = user_z)
        }
    })

    # Z Aggregation Button Label Update ####

    observeEvent({
        shiny::req(input$zAggregation)},{

            st <- input$zAggregation

            label = aggregationButtonLabel(st)

            shinyBS::updateButton(session, ns("zAggButton"), label = label, size = "small")
        })

    # Color Value Update ####

    colorChoices <- reactive({
        temp <- if(shiny::req(input$plotType) %in% c("Pie Chart", "Box Plot")){
            names(colClass()[grepl("character|factor|logical|ordered", colClass())])
        } else {
            names(data())
        }
        temp <- temp[order(temp)]
    })

    observe({
        shiny::validate(need(list(input$plotType, input$dataSet), FALSE))
        if({is.null(user_data)|is.null(user_color)}){
            shiny::updateSelectInput(session, "colorGroup", label = "Color", choices = colorChoices(), selected = colorChoices()[1])
        } else {
            shiny::updateSelectInput(session, "colorGroup", label = "Color", choices = colorChoices(), selected = user_color)
        }
    })

    # Size Value Update ####

    sizeChoices <- reactive({
        temp <- names(colClass()[grepl("numeric|integer", colClass())])
        temp <- temp[order(temp)]
    })

    observe({
        shiny::validate(need(list(input$plotType, input$dataSet), FALSE))
        if({is.null(user_data)|is.null(user_color)}){
            shiny::updateSelectInput(session, "sizeGroup", label = "Size", choices = sizeChoices(), selected = sizeChoices()[1])
        } else {
            shiny::updateSelectInput(session, "sizeGroup", label = "Size", choices = sizeChoices(), selected = user_size)
        }
    })

    # Bins value update
    histoBins <- reactive({
        shiny::validate(need(xSelectedClass(), F))
        if(xSelectedClass() %in% c("integer", "numeric")){
            input$histoBins
        } else {
            0
        }
    })

    # Network Value Update ####

    networkValueChoices <- reactive({
        temp <- names(colClass()[grepl("integer|numeric", colClass())])
        temp <- temp[order(temp)]
        temp <- temp[!grepl(paste(input$xValue, input$yValue, sep = "|"), temp)]
    })

    observe({
        shiny::validate(need(list(input$plotType, input$Links), FALSE))
        if({is.null(user_links)|is.null(user_value)}){
            shiny::updateSelectInput(session, "networkValue", label = "Value", choices = networkValueChoices(), selected = networkValueChoices()[1])
        } else {
            shiny::updateSelectInput(session, "networkValue", label = "Value", choices = networkValueChoices(), selected = user_value)
        }
    })

    # Network Settings Update ####

    networkSelectedClass <- reactive({

    })

    observe({
        shiny::validate(need(list(input$plotType, input$networkValue), FALSE))
        colNames <- if(input$plotType %in% c("Force Network", "Sankey Network")){
            colnames(data()$Links)
        }else {
            colnames(data())
        }

        selectedClass <- data.frame("ColNames" = colNames, "Class" = colClass()) %>%
            dplyr::filter(ColNames %in% input$networkValue) %>% dplyr::select(Class) %>% unlist(use.names = FALSE) %>% as.character()

        shiny::updateSelectInput(session, "networkSettings", label = NULL, choices = selectedClass, selected = selectedClass[1])
    })

    # Network Button Label Update ####

    observeEvent(shiny::req(input$networkSettings),{

        st <- input$networkSettings
        label = NULL
        switch(st,
               "numeric" = {
                   label = "NUM"
               },
               "integer" = {
                   label = "INT"
               })

        shinyBS::updateButton(session, ns("networkButton"), label = label, disabled = TRUE, size = "small")
    })

    # Network Nodes ID update ####
    # get column classes
    nodesColClass <- reactive({
        if(shiny::req(input$plotType) %in% c("Force Network", "Sankey Network")){
            sapply(data()$Nodes, class)
        } else {
            sapply(data(), class)
        }
    })

    nodeIdChoices <- reactive({
        temp <- if(shiny::req(input$plotType) %in% c("Force Network", "Sankey Network")){
            names(nodesColClass()[grepl("factor|character", nodesColClass())])
        } else{
            names(nodesColClass())
        }
        temp[order(temp)]
    })

    observe({
        shiny::validate(need(list(input$plotType, input$Nodes), FALSE))
        if({is.null(user_nodes)|is.null(user_node_id)}){
            shiny::updateSelectInput(session, "nodeId", choices = nodeIdChoices(), selected = nodeIdChoices()[1])
        } else {
            shiny::updateSelectInput(session, "nodeId", choices = nodeIdChoices(), selected = user_node_id)
        }
    })

    # Network Nodes Group update ####

    nodeGroupChoices <- reactive({
        shiny::req(nodesColClass())
        temp <- names(nodesColClass())
        temp <- temp[!grepl(input$nodeId, temp)]
    })

    observe({
        shiny::validate(need(list(input$plotType, input$Nodes), FALSE))
        if({is.null(user_nodes)|is.null(user_node_group)}){
            shiny::updateSelectInput(session, "nodeGroup", choices = nodeGroupChoices(), selected = nodeGroupChoices()[1])
        } else {
            shiny::updateSelectInput(session, "nodeGroup", choices = nodeGroupChoices(), selected = user_node_id)
        }
    })

    # # Aggregate the data for plotly plots
    # plot_Category <- reactive({
    #     shiny::req(input$plotType, data())
    #     dplyr::filter(plotChoicesDF, Type %in% input$plotType) %>% dplyr::select(Category) %>% unlist(use.names = F)
    # })
    #
    # data_agg <- reactive({
    #     cond <- !("Network Graph" %in% plot_Category())
    #     if(cond){
    #
    #     }
    # })

    # Return Settings List
    slist <- reactive({
        shiny::req(input$plotType, input$dataSet)
        #shiny::validate(need(list(input$plotType, input$dataSet, input$xValue), FALSE))
        list(
            "plot" = input$plotType,
            "dataSetName" = input$dataSet,
            "linkDataName" = input$Links,
            "nodeDataName" = input$Nodes,
            "data" = data(),
            "x" = input$xValue,
            "xSetting" = input$xSettings,
            "y" = input$yValue,
            "yAgg" = input$yAggregation,
            "y2" = input$y2Value,
            "y2Agg" = input$y2Aggregation,
            "z" = input$zValue,
            "zAgg" = input$zAggregation,
            "color" = input$colorGroup,
            "barMode" = input$barMode,
            "barOrientation" = input$barOrientation,
            "size" = input$sizeGroup,
            "bins" = histoBins(),
            "donutSize" = input$donutSize,
            "networkValue" = input$networkValue,
            "nodeId" = input$nodeId,
            "nodeGroup" = input$nodeGroup,
            "linkType" = input$linkType,
            "treeOrientation" = input$treeOrientation
        )
    })

    return(slist)
}
