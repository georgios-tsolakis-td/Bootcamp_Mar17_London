
#' @title RShiny_genFormula
#' @description Generates a formula
#' @family BoxModule
#' @rdname genFormula
#' @param _var A character string. Usually a variable name
#' @export
genFormula <- function(`_var`){as.formula(paste0("~`", `_var`, "`"))}

#' @title RShiny_generateMBarPlot
#' @description Generates a bar plot with 2 traces
#' @family Plotly Plots
#' @rdname generateMBarPlot
#' @param _plotData An aggregated data frame
#' @param _xVar A character string of a column name. Sets the x position.
#' @param _yVar A character string of a column name. Sets the y position.
#' @param _y2Var A character string of a column name. Sets the y2 position.
#' @param _xTittle A character string drescribing x-axis title.
#' @param _yTittle A character string drescribing y-axis title.
#' @param _xTickAngle An integer value Range -90 to 90 to rotate the x-axis labels
#' @param _yTickAngle An integer value Range -90 to 90 to rotate the y-axis labels
#' @param _top An integer value to set the top margin. Default = 100
#' @param _right An integer value to set the right margin. Default = 80
#' @param _bottom An integer value to set the bottom margin. Default = 80
#' @param _left An integer value to set the left margin. Default = 80
#' @param _alpha A fraction value to set the opacity of the markers Range 0 to 1
#' @import plotly
#' @export
generateMBarPlot <- function(`_plotData`, `_xVar`, `_yVar`,`_y2Var`, `_xTitle` = NULL, `_yTitle` = NULL, `_xTickAngle` = 0,
                             `_yTickAngle` = 0, `_top` = 100, `_right` = 80, `_bottom` = 80, `_left` = 80, `_legendO` = "Top Right", `_alpha` = .8){

    xValue <- genFormula(`_xVar`)
    yValue <- genFormula(`_yVar`)
    yValue2 <- genFormula(`_y2Var`)

    p <- plot_ly(data = `_plotData`, x = xValue, alpha = `_alpha`) %>%
        add_bars(y = yValue, name = `_yVar`) %>%
        add_bars(y = yValue2, name = `_y2Var`) %>%
        layout(xaxis = list(title = ifelse({`_xTitle` == ""|is.null(`_xTitle`)}, `_xVar`, `_xTitle`), tickangle = `_xTickAngle`),
               yaxis = list(title = ifelse({`_yTitle` == ""|is.null(`_yTitle`)}, `_yVar`, `_yTitle`), tickangle = `_yTickAngle`),
               margin = list(b = `_bottom`, l = `_left`, r = `_right`, t = `_top`),
               legend = list(orientation = ifelse(`_legendO` == "Top Right", "v", "h")))
    return(p)
}

#' @title RShiny_generateBarPlot
#' @description Generates a bar plot
#' @family Plotly Plots
#' @rdname generateBarPlot
#' @param _plotData An aggregated data frame
#' @param _xVar A character string of a column name. Sets the x position.
#' @param _yVar A character string of a column name. Sets the y position.
#' @param _color A character string of a column name. Sets the color of the markers.
#' @param _mode A character string of mode value. (accepts grouped, stacked)
#' @param _orientation A character string of plot orientation type. (accepts h, v)
#' @param _xTittle A character string drescribing x-axis title.
#' @param _yTittle A character string drescribing y-axis title.
#' @param _xTickAngle An integer value Range -90 to 90 to rotate the x-axis labels
#' @param _yTickAngle An integer value Range -90 to 90 to rotate the y-axis labels
#' @param _top An integer value to set the top margin. Default = 100
#' @param _right An integer value to set the right margin. Default = 80
#' @param _bottom An integer value to set the bottom margin. Default = 80
#' @param _left An integer value to set the left margin. Default = 80
#' @param _alpha A fraction value to set the opacity of the markers Range 0 to 1
#' @import plotly
#' @export
generateBarPlot <- function(`_plotData`, `_xVar`, `_yVar`, `_color`, `_mode`, `_orientation`, `_xTitle` = NULL, `_yTitle` = NULL, `_xTickAngle` = 0,
                            `_yTickAngle` = 0, `_top` = 100, `_right` = 80, `_bottom` = 80, `_left` = 80, `_legendO` = "Top Right", `_alpha` = .8){

    xValue <- genFormula(`_xVar`)
    yValue <- genFormula(`_yVar`)
    color <- genFormula(`_color`)

    if(`_orientation` == "v"){
        p <- plot_ly(data = `_plotData`, x = xValue, y = yValue, color = color, type = "bar", alpha = `_alpha`) %>%
            layout(barmode = `_mode`,
                   xaxis = list(title = ifelse({`_xTitle` == ""|is.null(`_xTitle`)}, `_xVar`, `_xTitle`), tickangle = `_xTickAngle`),
                   yaxis = list(title = ifelse({`_yTitle` == ""|is.null(`_yTitle`)}, `_yVar`, `_yTitle`), tickangle = `_yTickAngle`),
                   margin = list(b = `_bottom`, l = `_left`, r = `_right`, t = `_top`),
                   legend = list(orientation = ifelse(`_legendO` == "Top Right", "v", "h")))
    } else {
        p <- plot_ly(data = `_plotData`, x = yValue, y = xValue, color = color, type = "bar", alpha = `_alpha`, orientation = "h") %>%
            layout(barmode = `_mode`,
                   xaxis = list(title = ifelse({`_yTitle` == ""|is.null(`_yTitle`)}, `_yVar`, `_yTitle`), tickangle = `_yTickAngle`),
                   yaxis = list(title = ifelse({`_xTitle` == ""|is.null(`_xTitle`)}, `_xVar`, `_xTitle`), tickangle = `_xTickAngle`),
                   margin = list(b = `_bottom`, l = `_left`, r = `_right`, t = `_top`),
                   legend = list(orientation = ifelse(`_legendO` == "Top Right", "v", "h")))
    }

    return(p)
}

#' @title RShiny_generateScatterPlot
#' @description Generates a scatter plot
#' @family Plotly Plots
#' @rdname generateScatterPlot
#' @param _plotData An aggregated data frame
#' @param _xVar A character string of a column name. Sets the x position.
#' @param _yVar A character string of a column name. Sets the y position.
#' @param _color A character string of a column name. Sets the color of the markers.
#' @param _size A character string of a column name. Sets the size of the markers.
#' @param _xTittle A character string drescribing x-axis title.
#' @param _yTittle A character string drescribing y-axis title.
#' @param _xTickAngle An integer value Range -90 to 90 to rotate the x-axis labels
#' @param _yTickAngle An integer value Range -90 to 90 to rotate the y-axis labels
#' @param _top An integer value to set the top margin. Default = 100
#' @param _right An integer value to set the right margin. Default = 80
#' @param _bottom An integer value to set the bottom margin. Default = 80
#' @param _left An integer value to set the left margin. Default = 80
#' @param _alpha A fraction value to set the opacity of the markers Range 0 to 1
#' @import plotly
#' @export
generateScatterPlot <- function(`_plotData`, `_xVar`, `_yVar`, `_color`, `_size`, `_xTitle` = NULL, `_yTitle` = NULL, `_xTickAngle` = 0,
                                `_yTickAngle` = 0, `_top` = 100, `_right` = 80, `_bottom` = 80, `_left` = 80, `_legendO` = "Top Right", `_alpha` = .8){

    xValue <- genFormula(`_xVar`)
    yValue <- genFormula(`_yVar`)
    color <- genFormula(`_color`)
    size <- genFormula(`_size`)

    p <- plot_ly(data = `_plotData`, x = xValue, y = yValue, color = color, size = size, type = "scatter", mode = "markers", alpha = `_alpha`) %>%
        layout(xaxis = list(title = ifelse({`_xTitle` == ""|is.null(`_xTitle`)}, `_xVar`, `_xTitle`), tickangle = `_xTickAngle`),
               yaxis = list(title = ifelse({`_yTitle` == ""|is.null(`_yTitle`)}, `_yVar`, `_yTitle`), tickangle = `_yTickAngle`),
               margin = list(b = `_bottom`, l = `_left`, r = `_right`, t = `_top`),
               legend = list(orientation = ifelse(`_legendO` == "Top Right", "v", "h")))

    return(p)
}

#' @title RShiny_generateMLinePlot
#' @description Generates a line plot with 2 traces
#' @family Plotly Plots
#' @rdname generateMLinePlot
#' @param _plotData An aggregated data frame
#' @param _xVar A character string of a column name. Sets the x position.
#' @param _yVar A character string of a column name. Sets the y position.
#' @param _y2Var A character string of a column name. Sets the y2 position.
#' @param _xTittle A character string drescribing x-axis title.
#' @param _yTittle A character string drescribing y-axis title.
#' @param _xTickAngle An integer value Range -90 to 90 to rotate the x-axis labels
#' @param _yTickAngle An integer value Range -90 to 90 to rotate the y-axis labels
#' @param _top An integer value to set the top margin. Default = 100
#' @param _right An integer value to set the right margin. Default = 80
#' @param _bottom An integer value to set the bottom margin. Default = 80
#' @param _left An integer value to set the left margin. Default = 80
#' @param _alpha A fraction value to set the opacity of the markers Range 0 to 1
#' @import plotly
#' @export
generateMLinePlot <- function(`_plotData`, `_xVar`, `_yVar`, `_y2Var`, `_xTitle` = NULL, `_yTitle` = NULL, `_xTickAngle` = 0,
                              `_yTickAngle` = 0, `_top` = 100, `_right` = 80, `_bottom` = 80, `_left` = 80, `_legendO` = "Top Right", `_alpha` = .8){

    xValue <- genFormula(`_xVar`)
    yValue <- genFormula(`_yVar`)
    yValue2 <- genFormula(`_y2Var`)

    p <- plot_ly(data = `_plotData`, x = xValue, alpha = `_alpha`) %>%
        add_lines(y = yValue, name = `_yVar`, mode = "lines") %>%
        add_lines(y = yValue2, name = `_y2Var`, mode = "lines") %>%
        layout(xaxis = list(title = ifelse({`_xTitle` == ""|is.null(`_xTitle`)}, `_xVar`, `_xTitle`), tickangle = `_xTickAngle`),
               yaxis = list(title = ifelse({`_yTitle` == ""|is.null(`_yTitle`)}, `_yVar`, `_yTitle`), tickangle = `_yTickAngle`),
               margin = list(b = `_bottom`, l = `_left`, r = `_right`, t = `_top`),
               legend = list(orientation = ifelse(`_legendO` == "Top Right", "v", "h")))

    return(p)
}

#' @title RShiny_generateLinePlot
#' @description Generates a line plot
#' @family Plotly Plots
#' @rdname generateLinePlot
#' @param _plotData An aggregated data frame
#' @param _xVar A character string of a column name. Sets the x position.
#' @param _yVar A character string of a column name. Sets the y position.
#' @param _color A character string of a column name. Sets the color of the markers.
#' @param _xTittle A character string drescribing x-axis title.
#' @param _yTittle A character string drescribing y-axis title.
#' @param _xTickAngle An integer value Range -90 to 90 to rotate the x-axis labels
#' @param _yTickAngle An integer value Range -90 to 90 to rotate the y-axis labels
#' @param _top An integer value to set the top margin. Default = 100
#' @param _right An integer value to set the right margin. Default = 80
#' @param _bottom An integer value to set the bottom margin. Default = 80
#' @param _left An integer value to set the left margin. Default = 80
#' @param _alpha A fraction value to set the opacity of the markers Range 0 to 1
#' @import plotly
#' @export
generateLinePlot <- function(`_plotData`, `_xVar`, `_yVar`, `_color`, `_xTitle` = NULL, `_yTitle` = NULL, `_xTickAngle` = 0,
                             `_yTickAngle` = 0, `_top` = 100, `_right` = 80, `_bottom` = 80, `_left` = 80, `_legendO` = "Top Right", `_alpha` = .8){

    xValue <- genFormula(`_xVar`)
    yValue <- genFormula(`_yVar`)
    color <- genFormula(`_color`)

    p <- plot_ly(data = `_plotData`, x = xValue, y = yValue, color = color,  type = "scatter", mode = "lines", alpha = `_alpha`) %>%
        layout(xaxis = list(title = ifelse({`_xTitle` == ""|is.null(`_xTitle`)}, `_xVar`, `_xTitle`), tickangle = `_xTickAngle`),
               yaxis = list(title = ifelse({`_yTitle` == ""|is.null(`_yTitle`)}, `_yVar`, `_yTitle`), tickangle = `_yTickAngle`),
               margin = list(b = `_bottom`, l = `_left`, r = `_right`, t = `_top`),
               legend = list(orientation = ifelse(`_legendO` == "Top Right", "v", "h")))

    return(p)
}

#' @title RShiny_generateAreaPlot
#' @description Generates an area plot
#' @family Plotly Plots
#' @rdname generateAreaPlot
#' @param _plotData An aggregated data frame
#' @param _xVar A character string of a column name. Sets the x position.
#' @param _yVar A character string of a column name. Sets the y position.
#' @param _color A character string of a column name. Sets the color of the markers.
#' @param _xTittle A character string drescribing x-axis title.
#' @param _yTittle A character string drescribing y-axis title.
#' @param _xTickAngle An integer value Range -90 to 90 to rotate the x-axis labels
#' @param _yTickAngle An integer value Range -90 to 90 to rotate the y-axis labels
#' @param _top An integer value to set the top margin. Default = 100
#' @param _right An integer value to set the right margin. Default = 80
#' @param _bottom An integer value to set the bottom margin. Default = 80
#' @param _left An integer value to set the left margin. Default = 80
#' @param _alpha A fraction value to set the opacity of the markers Range 0 to 1
#' @import plotly
#' @export
generateAreaPlot <- function(`_plotData`, `_xVar`, `_yVar`, `_color`, `_xTitle` = NULL, `_yTitle` = NULL, `_xTickAngle` = 0,
                             `_yTickAngle` = 0, `_top` = 100, `_right` = 80, `_bottom` = 80, `_left` = 80, `_legendO` = "Top Right", `_alpha` = .8){

    xValue <- genFormula(`_xVar`)
    yValue <- genFormula(`_yVar`)
    color <- genFormula(`_color`)

    `_plotData` <- `_plotData` %>%
        tidyr::spread_(`_color`, `_yVar`)

    colNames <- names(`_plotData`)[-1]

    p <- plot_ly(data = `_plotData`, x = xValue, type = "scatter", mode = "none", name = `_color`, alpha = `_alpha`)

    for(`_trace` in colNames){
        p <- p %>% add_trace(y = genFormula(`_trace`), name = `_trace`, fill = "tozeroy")
    }

    p <- p %>%
        layout(xaxis = list(title = ifelse({`_xTitle` == ""|is.null(`_xTitle`)}, `_xVar`, `_xTitle`), tickangle = `_xTickAngle`),
               yaxis = list(title = ifelse({`_yTitle` == ""|is.null(`_yTitle`)}, `_yVar`, `_yTitle`), tickangle = `_yTickAngle`),
               margin = list(b = `_bottom`, l = `_left`, r = `_right`, t = `_top`),
               legend = list(orientation = ifelse(`_legendO` == "Top Right", "v", "h")))

    return(p)
}

#' @title RShiny_generateBoxPlot
#' @description generateBoxPlot description
#' @family Plotly Plots
#' @rdname generateBoxPlot
#' @param _xVar A character string of a column name. Sets the x position.
#' @param _yVar A character string of a column name. Sets the y position.
#' @param _color A character string of a column name. Sets the color of the boxes
#' @param _xTittle A character string drescribing x-axis title.
#' @param _yTittle A character string drescribing y-axis title.
#' @param _xTickAngle An integer value Range -90 to 90 to rotate the x-axis labels
#' @param _yTickAngle An integer value Range -90 to 90 to rotate the y-axis labels
#' @param _top An integer value to set the top margin. Default = 100
#' @param _right An integer value to set the right margin. Default = 80
#' @param _bottom An integer value to set the bottom margin. Default = 80
#' @param _left An integer value to set the left margin. Default = 80
#' @param _alpha A fraction value to set the opacity of the markers Range 0 to 1
#' @import plotly
#' @export
generateBoxPlot <- function(`_plotData`, `_xVar`, `_yVar`, `_color`, `_xTitle` = NULL, `_yTitle` = NULL,
                            `_xTickAngle` = 0, `_yTickAngle` = 0, `_top` = 100,`_right` = 80, `_bottom` = 80,
                            `_left` = 80, `_legendO` = "Top Right", `_alpha` = .8){

    xValue <- genFormula(`_xVar`)

    yValue <- genFormula(`_yVar`)

    color <- if(`_color` != ""){
        genFormula(`_color`)
    }else {
        ""
    }

    p <- plot_ly(data = `_plotData`, x = xValue , y = yValue, color = color, type = "box") %>%
        layout(xaxis = list(title = ifelse({`_xTitle` == ""|is.null(`_xTitle`)}, `_xVar`, `_xTitle`),
                            tickangle = `_xTickAngle`),
               yaxis = list(title = ifelse({`_yTitle` == ""|is.null(`_yTitle`)}, `_yVar`, `_yTitle`),
                            tickangle = `_yTickAngle`),
               margin = list(b = `_bottom`, l = `_left`, r = `_right`, t = `_top`),
               legend = list(orientation = ifelse(`_legendO` == "Top Right", "v", "h")))

    return(p)
}

#' @title RShiny_generatePieChart
#' @description generatePieChart description
#' @family Plotly Plots
#' @rdname generatePieChart
#' @param _labels A character string of a column name. Sets the labels of the Pie Chart
#' @param _value A character string of a column name.
#' @param _top An integer value to set the top margin. Default = 100
#' @param _right An integer value to set the right margin. Default = 80
#' @param _bottom An integer value to set the bottom margin. Default = 80
#' @param _left An integer value to set the left margin. Default = 80
#' @import plotly
#' @export
generatePieChart <- function(`_plotData`, `_labels`, `_value`, `_hole`, `_top` = 100, `_right` = 80,
                             `_bottom` = 80, `_left` = 80, `_legendO` = "Top Right"){

    lables <- genFormula(`_labels`)
    value <- genFormula(`_value`)

    p <- plot_ly(`_plotData`, labels = lables, values = value, textposition = 'inside', textinfo = 'label+percent',
                 marker = list(line = list(color = '#FFFFFF', width = 1))) %>%
        add_pie(hole = `_hole`) %>%
        layout(showlegend = F,
               xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
               yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
               margin = list(b = `_bottom`, l = `_left`, r = `_right`, t = `_top`),
               legend = list(orientation = ifelse(`_legendO` == "Top Right", "v", "h")))

    return(p)
}

#' @title RShiny_generateContourPlot
#' @description generateContourPlot description
#' @family Plotly Plots
#' @rdname generateContourPlot
#' @param _xVar A character string of a column name. Sets the x position.
#' @param _yVar A character string of a column name. Sets the y position.
#' @param _zVar A character string of a column name. Sets the contours
#' @param _xTittle A character string drescribing x-axis title.
#' @param _yTittle A character string drescribing y-axis title.
#' @param _xTickAngle An integer value Range -90 to 90 to rotate the x-axis labels
#' @param _yTickAngle An integer value Range -90 to 90 to rotate the y-axis labels
#' @param _top An integer value to set the top margin. Default = 100
#' @param _right An integer value to set the right margin. Default = 80
#' @param _bottom An integer value to set the bottom margin. Default = 80
#' @param _left An integer value to set the left margin. Default = 80
#' @import plotly
#' @export
generateContourPlot <- function(`_plotData`, `_xVar`, `_yVar`, `_zVar`, `_xTitle` = NULL, `_yTitle` = NULL,
                                `_xTickAngle` = 0, `_yTickAngle` = 0, `_top` = 100,`_right` = 80, `_bottom` = 80,
                                `_left` = 80, `_legendO` = "Top Right"){

    xValue <- genFormula(`_xVar`)
    yValue <- genFormula(`_yVar`)
    zValue <- genFormula(`_zVar`)

    p <- plot_ly(data = `_plotData`, x = xValue, y = yValue, z = zValue,  type = "contour") %>%
        layout(xaxis = list(title = ifelse({`_xTitle` == ""|is.null(`_xTitle`)}, `_xVar`, `_xTitle`),
                            tickangle = `_xTickAngle`),
               yaxis = list(title = ifelse({`_yTitle` == ""|is.null(`_yTitle`)}, `_yVar`, `_yTitle`),
                            tickangle = `_yTickAngle`),
               margin = list(b = `_bottom`, l = `_left`, r = `_right`, t = `_top`),
               legend = list(orientation = ifelse(`_legendO` == "Top Right", "v", "h")))

    return(p)
}

#' @title RShiny_generateHeatmap
#' @description generateHeatmap description
#' @family Plotly Plots
#' @rdname generateHeatmap
#' @param _xVar A character string of a column name. Sets the x position.
#' @param _yVar A character string of a column name. Sets the y position.
#' @param _zVar A character string of a column name. Sets the contours
#' @param _xTittle A character string drescribing x-axis title.
#' @param _yTittle A character string drescribing y-axis title.
#' @param _xTickAngle An integer value Range -90 to 90 to rotate the x-axis labels
#' @param _yTickAngle An integer value Range -90 to 90 to rotate the y-axis labels
#' @param _top An integer value to set the top margin. Default = 100
#' @param _right An integer value to set the right margin. Default = 80
#' @param _bottom An integer value to set the bottom margin. Default = 80
#' @param _left An integer value to set the left margin. Default = 80
#' @import plotly
#' @export
generateHeatmap <- function(`_plotData`, `_xVar`, `_yVar`, `_zVar`, `_xTitle` = NULL, `_yTitle` = NULL,
                                `_xTickAngle` = 0, `_yTickAngle` = 0, `_top` = 100,`_right` = 80, `_bottom` = 80,
                                `_left` = 80, `_legendO` = "Top Right"){

    xValue <- genFormula(`_xVar`)
    yValue <- genFormula(`_yVar`)
    zValue <- genFormula(`_zVar`)

    p <- plot_ly(data = `_plotData`, x = xValue, y = yValue, z = zValue,  type = "heatmap") %>%
        layout(xaxis = list(title = ifelse({`_xTitle` == ""|is.null(`_xTitle`)}, `_xVar`, `_xTitle`),
                            tickangle = `_xTickAngle`),
               yaxis = list(title = ifelse({`_yTitle` == ""|is.null(`_yTitle`)}, `_yVar`, `_yTitle`),
                            tickangle = `_yTickAngle`),
               margin = list(b = `_bottom`, l = `_left`, r = `_right`, t = `_top`),
               legend = list(orientation = ifelse(`_legendO` == "Top Right", "v", "h")))

    return(p)
}

#' @title RShiny_generateSimpleNetwork
#' @description generateSimpleNetwork description
#' @family NetworkD3 Graphs
#' @rdname generateSimpleNetwork
#' @param _source A character string of a column name. Sets the x position.
#' @param _target A character string of a column name. Sets the y position.
#' @import networkD3
#' @export
generateSimpleNetwork <- function(`_plotData`, `_source`, `_target`){

    p <- networkD3::simpleNetwork(Data = `_plotData`, Source = `_source`, `_target`)

    return(p)
}


#' @title RShiny_generateForceNetwork
#' @description generateForceNetwork description
#' @family NetworkD3 Graphs
#' @rdname generateForceNetwork
#' @param _links add desc
#' @param _nodes add desc
#' @param _source A character string of a column name. Sets the x position.
#' @param _target A character string of a column name. Sets the y position.
#' @param _value add desc
#' @param _nodeId add desc
#' @param _group add desc
#' @import networkD3
#' @export
generateForceNetwork <- function(`_links`, `_nodes`, `_source`, `_target`, `_value`, `_nodeId`, `_group`){

    p <- networkD3::forceNetwork(Links = `_links`, Nodes =  `_nodes`, Source = `_source`, Target = `_target`,
                                 Value = `_value`, NodeID = `_nodeId`, Group = `_group`)

    return(p)
}


#' @title RShiny_generateSankeyNetwork
#' @description generateSankeyNetwork description
#' @family NetworkD3 Graphs
#' @rdname generateSankeyNetwork
#' @param _links add desc
#' @param _nodes add desc
#' @param _source A character string of a column name. Sets the x position.
#' @param _target A character string of a column name. Sets the y position.
#' @param _value add desc
#' @param _nodeId add desc
#' @param _group add desc
#' @import networkD3
#' @export
generateSankeyNetwork <- function(`_links`, `_nodes`, `_source`, `_target`, `_value`, `_nodeId`){

    p <- networkD3::sankeyNetwork(Links = `_links`, Nodes =  `_nodes`, Source = `_source`, Target = `_target`,
                                 Value = `_value`, NodeID = `_nodeId`)

    return(p)
}

