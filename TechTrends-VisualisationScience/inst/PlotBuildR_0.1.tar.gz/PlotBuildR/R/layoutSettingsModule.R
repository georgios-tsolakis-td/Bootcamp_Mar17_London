# Layout Settings

# simple Network: fontSize, linkColor, nodeColor, textColor, opacity
# force Network: fontSize, linkColor, opacity
# sankey Network: fontSize, nodeWidth, nodePadding, margin
# dendro Network: fontSize, linkColour, nodeColour, nodeStroke, textColour, textOpacity, textRotate, opacity, margins
#   layout(                        # all of layout's properties: /r/reference/#layout
# title = "Unemployment", # layout's title: /r/reference/#layout-title
# xaxis = list(     # layout's xaxis is a named list. List of valid keys: /r/reference/#layout-xaxis
#     title = "Time", # xaxis's title: /r/reference/#layout-xaxis-title
#     tickangle
#     showgrid = F),       # xaxis's showgrid: /r/reference/#layout-xaxis-showgrid
# yaxis = list(           # layout's yaxis is a named list. List of valid keys: /r/reference/#layout-yaxis
#     title = "uidx")     # yaxis's title: /r/reference/#layout-yaxis-title
# )


#' @title RShiny_layoutBootstrapPage
#' @description layoutBootstrapPage creates two inline shinyUI input objects. Specifically created to add a title and a value of tick angle for an axis
#' @family LayoutModule
#' @rdname layoutBootstrapPage
#' @param input1_id An id for a textInput object. To be passed inside a namespaced function. Eg. `ns("inputID")`
#' @param input1_label A character string describing the textInput object. Defaults to NULL
#' @param input1_placeholder A character string giving the user a hint as to what can be entered into the textInput object. Defaults to NULL
#' @param input2_id An id for a numericInput object. To be passed inside a namespaced function. Eg. `ns("inputID")`
#' @param input2_label A character string describing the numericInput object. Defaults to NULL
#' @import shiny
#' @export
layoutBootstrapPage <- function(input1_id, input1_label = NULL, input1_placeholder = NULL, input2_id, input2_label = NULL){
    bootstrapStyle <- "display:inline-block; font-size:14px;"
    bootstrapPage(
        div(style= bootstrapStyle,
            textInput(input1_id, label = input1_label, width = "150px", placeholder = input1_placeholder)
        ),
        div(style= bootstrapStyle,
            numericInput(input2_id, label = input2_label, width = "100px", value = 0, min = -90, max = 90, step = 1))
    )
}


#' @title RShiny_layoutSettingsUI
#' @description The layoutSettingsUI creates a UI frame to get various plot layout input values from the user.
#' It is passed in a bsModal which is accessed when the user clicks the layout settings button placed at the header of the plot box
#' @family LayoutModule
#' @rdname layoutSettingsUI
#' @param id The id string that will be used to access the values
#' @import shiny
#' @export
layoutSettingsUI <- function(id){
    ns <- NS(id)
    bootstrapStyle <- "display:inline-block; font-size:12px;"
    tagList(
        textInput(ns("chartTitle"), label = "Chart Title", width = "100%", placeholder = "plot title"),
        conditionalPanel( # Chart, X & Y Axis Title ####
                          condition = sprintf("output['%s'] != 'Network Graphs' & output['%s'] != 'Pie Chart'", ns("plotCat"), ns("plot_type")),
                          layoutBootstrapPage(input1_id = ns("xTitle"), input1_label = "X-Axis Name", input1_placeholder = "eg. x variable",
                                              input2_id = ns("xTickAngle"), input2_label = "Tick Angle"),
                          layoutBootstrapPage(input1_id = ns("yTitle"), input1_label = "Y-Axis Name", input1_placeholder = "eg. y variable",
                                              input2_id = ns("yTickAngle"), input2_label = "Tick Angle")
        ),
        conditionalPanel(# Z Axis Title ####
                         condition = sprintf("output['%s'] == '3D Plots'",ns("plotCat")),
                         layoutBootstrapPage(input1_id = ns("zTitle"), input1_label = "Z-Axis Name", input1_placeholder = "eg. z variable",
                                             input2_id = ns("zTickAngle"), input2_label = "Tick Angle")

        ),
        conditionalPanel(# Margin ####
                         condition = sprintf("output['%s'] != 'Network Graphs'",ns("plotCat")),
                         h4("Margins"),
                         bootstrapPage(
                             div(style= bootstrapStyle,
                                 numericInput(ns("marginT"), label = "t", width = "124px", value = 80, min = 0, max = 150, step = 1)
                             ),
                             div(style= bootstrapStyle,
                                 numericInput(ns("marginR"), label = "r", width = "124px", value = 80, min = 0, max = 150, step = 1)
                             ),
                             div(style= bootstrapStyle,
                                 numericInput(ns("marginB"), label = "b", width = "124px", value = 80, min = 0, max = 150, step = 1)
                             ),
                             div(style= bootstrapStyle,
                                 numericInput(ns("marginL"), label = "l", width = "124px", value = 80, min = 0, max = 150, step = 1)
                             )

                         )
        ),
        conditionalPanel(# Legend ####
                         condition = sprintf("output['%s'] != 'Network Graphs'",ns("plotCat")),
                         h4("Margins"),
                         selectInput(ns("legendOrientation"), label = "Orientation", choices = c("Top Right", "Bottom Left"), selected = "Top Right")
        )
        # conditionalPanel(# Network graphs settings####
        #                  condition = sprintf("output['%s'] == 'Network Graphs'",ns("plotCat")),
        #                  bootstrapPage(
        #                      div(style= bootstrapStyle,
        #                          numericInput(ns("marginT"), label = "t", width = "62px", value = 0, min = 0, max = 100, step = 1)
        #                      ),
        #                      div(style= bootstrapStyle,
        #                          numericInput(ns("marginR"), label = "r", width = "62px", value = 0, min = 0, max = 100, step = 1)
        #                      ),
        #                      div(style= bootstrapStyle,
        #                          numericInput(ns("marginB"), label = "b", width = "62px", value = 0, min = 0, max = 100, step = 1)
        #                      ),
        #                      div(style= bootstrapStyle,
        #                          numericInput(ns("marginL"), label = "l", width = "62px", value = 0, min = 0, max = 100, step = 1)
        #                      )
        #
        #                  )
        #
        #
        # )
    )
}

#' @title RShiny_layoutSettings
#' @description The layoutSettings module returns a lists of user defined layout settings values accessed by generate plot
#' @family LayoutModule
#' @rdname layoutSettings
#' @param input add details
#' @param output add details
#' @param session add details
#' @param user_plot Accesses the value of the selected plot type
#' @import shiny dplyr
#' @export
layoutSettings <- function(input, output, session, user_plot = NULL, user_title = NULL){

    plotChoicesDF <- plotChoices()[[2]]
    output$plotCat <- reactive({
        validate(need(user_plot(), FALSE))
        filter(plotChoicesDF, Type %in% user_plot()) %>% select(Category) %>% unlist(use.names = F)
    })

    output$plot_type <- reactive({user_plot()})

    outputOptions(output, "plotCat", suspendWhenHidden=FALSE)
    outputOptions(output, "plot_type", suspendWhenHidden=FALSE)

    # Update Plot Title ####
    observe({
        if({is.null(user_title)}){
            updateTextInput(session, "chartTitle", value = "Edit Plot Title")
        } else {
            updateTextInput(session, "chartTitle", value = user_title)
        }
    })

    sList <- reactive({
        req(user_plot())
        list(
            "title" = input$chartTitle,
            "xTitle" = input$xTitle,
            "xTickAngle" = input$xTickAngle,
            "yTitle" = input$yTitle,
            "yTickAngle" = input$yTickAngle,
            "zTitle" = input$zTitle,
            "zTickAngle" = input$zTickAngle,
            "t" = input$marginT,
            "r" = input$marginR,
            "b" = input$marginB,
            "l" = input$marginL,
            "legendO" = input$legendOrientation
        )
    })
    return(sList)
}
