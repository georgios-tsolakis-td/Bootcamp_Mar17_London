library(testthat)
library(PlotBuildR)

test_check("PlotBuildR")
