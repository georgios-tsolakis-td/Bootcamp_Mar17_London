source("../../inst/dataFiles.R")

list_to_df <- function(x, key, value){
    as.data.frame(x, stringsAsFactors = FALSE) %>% tbl_df %>%
        gather(key, value) %>%
        distinct
}
fileNames <- ls()
loadedFiles <- as_data_frame(cbind(fileNames, do.call(rbind, lapply(fileNames, function(x)class(get(x)))))[,1:2])
names(loadedFiles)[2] <- "class"

acceptedClasses <- c("data.frame", "tbl_df", "tibble", "data.table", "tbl_dt")
excludedFiles <- c("grid", "loadedFiles", "aggChoicesDF", "plotChoicesDF")
# filters only data.tables, data.frames, tibbles, tbl_dt and tbl_df objects loaded in R memory
dataChoices <- filter(loadedFiles, class %in% acceptedClasses,
                      !(fileNames %in% excludedFiles)) %>%
    select(fileNames) %>% unlist(use.names = FALSE)

plotChoices <- list("Classic Plots" = c("Multiple Bar Plot","Bar Plot", "Scatter Plot","Multiple Line Plot" ,"Line Plot", "Area Plot"),
                    "Statistical Plots" = c("Histogram", "Box Plot", "Pie Chart"),
                    "3D Plots" = c("Heatmap", "Contour Plot"),
                    "Network Graphs" = c("Simple Network", "Force Network", "Sankey Network", "Dendro Network"),
                    "Misc" = c("Time Series", "Pivot Table", "Data Table"))

aggChoices <- list("Operations" = c("Count", "Mean", "Median", "Sum"),
                   #"Transformation" = c("Exponential", "Log", "Square", "Square Root"),
                   "Error" = c("MAE", "RMSE"))

aggChoicesDF <- list_to_df(aggChoices, "AggregationCategory", "AggregationType")

bootstrapStyle <- "display:inline-block; font-size:14px;"


plotSettingsUI <- function(id){
    ns <- NS(id)
    tagList(
        verbatimTextOutput(ns("txt")),
        selectInput(ns("plotType"), label = "Plot Type", choices = NULL),
        conditionalPanel(
            condition = sprintf("input['%s'] == 'Force Network'|
                                input['%s'] == 'Sankey Network'",
                                ns("plotType"), ns("plotType")),
            bootstrapPage(
                div(style= bootstrapStyle,
                    selectInput(ns("Links"), label = "Links", choices = NULL, width = "125px")
                ),
                div(style= bootstrapStyle,
                    selectInput(ns("Nodes"), label = "Nodes", choices = NULL, width = "125px"))
            )
        ),
        conditionalPanel(
            condition = sprintf("input['%s'] != 'Force Network' &
                                input['%s'] != 'Sankey Network'",
                                ns("plotType"), ns("plotType")),
            selectInput(ns("dataSet"), label = "Dataset Choices", choices = NULL)
        ),
        sliderInput(ns("slider1"), "Slider 1", 0, 50, 1, 1),
        bsButton(ns("but1"), "Button 1", type = "action"),
        bsModal(ns("mod1"), title = "Modal 1", trigger = ns("but1"), size = "small",
                verbatimTextOutput(ns("text1")))
    )
}

plotSettings <- function(input, output, session, user_data = NULL, user_links = NULL, user_nodes = NULL,
                         user_x = NULL, user_y = NULL, user_z = NULL, user_color = NULL, user_plot = NULL, user_size = NULL){

    # Plot Type Update ####
    observe({
        cond <- is.null(user_plot)
        selected <- if(cond){
            temp <- plotChoices %>% unlist(use.names = F)
            temp[ceiling(runif(1, 1, length(plotChoices)))]
        } else{
            user_plot
        }
        updateSelectInput(session, "plotType", choices = plotChoices, selected = selected)
    })

    # Data Set Update ####

    dataChoices <- reactive({

        temp <- filter(loadedFiles, !(fileNames %in% excludedFiles))

        temp2 <- if(req(input$plotType) == "Dendro Network"){
            filter(temp, class == "hclust")
        } else if(input$plotType == "Time Series"){
            filter(temp, class %in% c("mts", "ts", "xts"))
        } else{
            filter(temp, class %in% acceptedClasses)
        }
        temp3 <- temp2 %>% select(fileNames) %>% unlist(use.names = FALSE)
    })

    observe({
        if(is.null(user_data)){
            updateSelectInput(session, "dataSet", choices = dataChoices(), selected = dataChoices()[ceiling(runif(1, 1, length(dataChoices())))])
        } else {
            updateSelectInput(session, "dataSet", choices = dataChoices(), selected = user_data)
        }
    })

    observe({
        if(is.null(user_links)){
            updateSelectInput(session, "Links", choices = dataChoices(), selected = dataChoices()[ceiling(runif(1, 1, length(dataChoices())))])
        }else{
            updateSelectInput(session, "Links", choices = dataChoices(), selected = user_links)
        }
    })

    observe({
        if(is.null(user_nodes)){
            updateSelectInput(session, "Nodes", choices = dataChoices(), selected = dataChoices()[ceiling(runif(1, 1, length(dataChoices())))])
        }else{
            updateSelectInput(session, "Nodes", choices = dataChoices(), selected = user_nodes)
        }
    })

    data <- reactive({
        validate(need(input$dataSet, FALSE))

        if(req(input$plotType) %in% c("Force Network", "Sankey Network")){
            list("Links" = get(input$Links), "Nodes" = get(input$Nodes))
        }else
            get(input$dataSet)
    })

    observeEvent(input$slider1,{
        ns <- session$ns
        sv <- input$slider1
        disabled = NULL
        label = NULL

        if(sv >0 && sv < 20){
            disabled = TRUE
            label = "Cant do it"
        } else if(sv >=20 && sv <35){
            disabled = FALSE
            label = "Perfect"
        } else{
            disabled = TRUE
            label = "Too Large"
        }
        updateButton(session, ns("but1"), label = label, disabled = disabled)
    })

    output$text1 <- renderText({
        "Success"
    })

    return(data)
}
