# PlotBuildR

The goal of PlotBuildR is to ...

## Example

This is a basic example which shows you how to solve a common problem:

```R
...
```
