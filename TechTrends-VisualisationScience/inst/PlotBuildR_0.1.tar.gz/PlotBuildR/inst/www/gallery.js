(function(document, delay, $) {

    const $wrapper = $(document.currentScript).closest('.modal-content');
    const $plotType = $wrapper.find('[id$=plotSettings-plotType]');
    const $formGroup = $plotType.closest('.form-group');
    const $modalBody = $plotType.closest('.tab-pane');

    $formGroup.hide();
    $wrapper.parent().css('width', '56vw');

    delay(() => {
        
        const plotTypeSelectize = $plotType[0].selectize;
        const types = plotTypeSelectize.currentResults.items.map(x => x.id);
        $modalBody.prepend('<div class="plot-gallery"></div>');
        const gallery = $modalBody.find('.plot-gallery');

        window.selectPlotType = function(type) { 
            plotTypeSelectize.setValue(type);
            const $elem = $(event.target);

            $('.exhibit-container').removeClass('selected');
            if ($elem.hasClass('exhibit-container')) {
                $elem.addClass('selected');
            } else {
                $elem.closest('.exhibit-container').addClass('selected');
            }
        };

        const currentValue = plotTypeSelectize.getValue().replace(/\s+/g, '').toLowerCase();

        types.forEach(type => {
            const typeClass = type.replace(/\s+/g, '').toLowerCase();

            gallery.append(`<div class="exhibit-container ${ currentValue === typeClass ? 'selected' : '' }" onclick="selectPlotType('${type}')">
                <div class="exhibit ${typeClass}"></div>
                <div class="title">${type}</div>
            </div>`);
        });

    }, 1000);

})(document, setTimeout, jQuery);