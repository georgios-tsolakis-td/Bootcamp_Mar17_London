# Some explaination is provided in the server logic

source("global.R")
ui_header <- dashboardHeader()

# ui_sidebar -------------------------------------------
ui_sidebar <- dashboardSidebar(disable = TRUE

)

#ui_body ------------------------------------------------
ui_body <- dashboardBody(
    fluidRow(
        box(
            h3("Plot Settings 1"),
            column(
                width = 2,
                actionButton("button1", icon("cog", lib= "glyphicon"))
            ),
            column(
                width = 10,
                "It's a test application that creates 2 plot settings modals and returns two data tables showing the data set selected in the plot settings modal"
            )
        ),
        box(
            h3("Plot Settings 2"),
            column(
                width = 2,
                actionButton("button2", icon("cog", lib= "glyphicon"))
            ),
            column(
                width = 10,
                "You can also pass a list of reactive data frames to the `user_reactive_data` argument and you can preselect any reactive data frame as well"
            )
        )
    ),
    bsModal("appModal1", "Plot Settings", trigger = "button1", plotSettingsUI("settings1"), size = "small"),
    bsModal("appModal2", "Plot Settings", trigger = "button2", plotSettingsUI("settings2"), size = "small"),
    br(),
    fluidRow(
        column(width = 6,
               h2("Output of Plot Settings 1"),
               dataTableOutput("table1")
        ),
        column(width = 6,
               h2("Output of Plot Settings 2"),
               dataTableOutput("table2")
        )
    )
)

ui <- dashboardPage(
    ui_header,
    ui_sidebar,
    ui_body,
    skin = "red"
)


# server ---------------------------------------------------
server <- function(input,output,session){

    # Default User settings for plotSettingsModule - some of them only work with certain plot type
    #
    # user_data = NULL, user_reactive_data = NULL, user_links = NULL, user_nodes = NULL, user_x = NULL,
    # user_y = NULL, user_y2 = NULL, user_z = NULL, user_color = NULL, user_size = NULL, user_value = NULL,
    # user_node_id = NULL, user_node_group = NULL, user_plot = NULL
    #
    # Let's make some reactive data frames and pass it to the plotSettingsModule.
    # There are two methods by which we can pass the reactive values
    #
    # 1. As Reactive Values - define an empty reactiveValues variable and define all the reactive data frames that you want to pass in it
    dataset <- reactiveValues()
    dataset$TexasHousing2 <- reactive({
        TexasHousing %>% filter(sales > 100)
    })
    dataset$AirPassengers2 <- reactive({
        AirPassengers %>% filter(month == "Jan")
    })
    # Now pass the reactiveValues variable without quotes
    s1 <- callModule(plotSettings, "settings1", user_reactive_data = dataset)

    output$table1 <- renderDataTable({
        s1()$data
    })

    # 2. As List - define an empty list and define all the reactive data frames that you want to pass in it
    dataset2 <- list()
    dataset2$AirPassengers3 <- reactive({
        AirPassengers %>% filter(month == "Feb")
    })
    dataset2$TexasHousing3 <- reactive({
        TexasHousing %>% filter(inventory > 6.5)
    })
    # Moreover, you can pass the name of the reactive data frame that you want to select
    s2 <- callModule(plotSettings, "settings2", user_data = "TexasHousing3", user_reactive_data = dataset2)

    output$table2 <- renderDataTable({
        s2()$data
    })

    # env <- environment()
    #
    # output$testEnv <- renderText({ls(env)})

    # outputExp <- reactive({
    #     switch(input$rdButton,
    #            "Verbatim" = as.expression("renderText({'Hello'})"),
    #            "Text" - as.expression("renderPrint({'Print'})"))
    # })
    #
    # output$testOt <- eval(outputExp())
    #
    # output$ui <- renderUI({
    #     verbatimTextOutput("testOt")
    # })
    # output$data <- renderDataTable(s())
    # output$plot <- renderPlotly({
    #     req(s()$x)
    #     xValue <- as.formula(paste0("~`", s()$x, "`"))
    #     plot_ly(get(s()$data), x = xValue, type = "histogram")
    # })
}

shinyApp(ui,server)
