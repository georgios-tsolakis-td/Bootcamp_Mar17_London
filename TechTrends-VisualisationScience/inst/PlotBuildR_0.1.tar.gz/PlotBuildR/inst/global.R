if(!require(devtools)) {install.packages("devtools", dependencies = TRUE);require(devtools)}
if(!require(lazyeval)) {devtools::install_github("hadley/lazyeval");require(lazyeval)}
if(!require(shiny)) {devtools::install_github("rstudio/shiny");require(shiny)}
if(!require(shinydashboard)) {install.packages("shinydashboard", dependencies = TRUE);require(shinydashboard)}
if(!require(shinyjs)) {install.packages("shinyjs", dependencies = TRUE);require(shinyjs)}
if(!require(shinyBS)) {devtools::install_github("ebailey78/shinyBS", ref = "shinyBS3");require(shinyBS)}
if(!require(shinythemes)) {install.packages("shinythemes", dependencies = TRUE);require(shinythemes)}
if(!require(data.table)) {install.packages("data.table", dependencies = TRUE);require(data.table)}
if(!require(plyr)) {install.packages("plyr", dependencies = TRUE);require(plyr)}
if(!require(dplyr)) {devtools::install_github("hadley/dplyr");require(dplyr)}
if(!require(dtplyr)) {install.packages("dtplyr", dependencies = TRUE);require(dtplyr)}
if(!require(stringr)) {install.packages("stringr", dependencies = TRUE);require(stringr)}
if(!require(flexdashboard)) {install.packages("flexdashboard", dependencies = TRUE);require(flexdashboard)}
if(!require(networkD3)) {install.packages("networkD3", dependencies = TRUE);require(networkD3)}
if(!require(plotly)) {devtools::install_github("ropensci/plotly");require(plotly)}
if(!require(tidyr)) {install.packages("tidyr", dependencies = TRUE);require(tidyr)}
if(!require(dygraphs)) {install.packages("dygraphs", dependencies = TRUE);require(dygraphs)}
if(!require(xts)) {install.packages("xts", dependencies = TRUE);require(xts)}
library(PlotBuildR)

#if(!require(rhandsontable)) {install.packages("rhandsontable", dependencies = TRUE);require(rhandsontable)}
source("dataFiles.R")
df_list_test = ls()

df_list_test2 = c("TexasHousing")

