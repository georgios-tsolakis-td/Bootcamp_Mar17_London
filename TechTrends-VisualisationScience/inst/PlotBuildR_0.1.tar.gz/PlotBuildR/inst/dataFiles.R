library(data.table)
library(dplyr)
library(dtplyr)
library(ggplot2)
library(plotly)

# File to source all the data sets
iris <- iris %>% tbl_dt
mtcars <- mtcars %>% tbl_df %>%
    mutate(vs = as.factor(vs),
           am = as.factor(am),
           gear = as.factor(gear),
           carb = as.factor(carb),
           cyl = as.factor(cyl))
grid <- expand.grid(
    year = seq(1949, 1960, 1),
    month = c("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec")) %>% tbl_df %>%
    arrange(year)

AirPassengers <- cbind(grid, datasets::AirPassengers %>% data.table)
colnames(AirPassengers)[3] <- "passengers"

TexasHousing <- select(txhousing, -date)

URL <- paste0("https://cdn.rawgit.com/christophergandrud/networkD3/",
              "master/JSONdata/miserables.json")

MisJson <- jsonlite::fromJSON(URL)

misLinks <- MisJson$links
misNodes <- MisJson$nodes

URL <- paste0('https://cdn.rawgit.com/christophergandrud/networkD3/',
              'master/JSONdata/energy.json')
energy <- jsonlite::fromJSON(URL)

energyLinks <- energy$links
energyNodes <- energy$nodes

#energyLinks <- mutate_each(energyLinks, funs(as.factor), -value)
