source("global.R")
plotChoices <- c("Bar Plot", "Scatter Plot", "Line Plot", "Area Plot", "Histogram", "Box Plot", "Heatmap", "Contour Plot", "Pie Chart")
plotChoices <- plotChoices[order(plotChoices)]

aggChoices <- list("Operations" = c("Count", "Mean", "Median", "Sum"),
                   #"Transformation" = c("Exponential", "Log", "Square", "Square Root"),
                   "Error" = c("MAE", "RMSE"))

bootstrapStyle <- "display:inline-block; font-size:14px;"

# Modular Functions ------------------------------------
modularUI <- function(id, label, ...){
    ns <- NS(id)
    tagList()
}


# ui_header -------------------------------------------
ui_header <- dashboardHeader()

# ui_sidebar -------------------------------------------
ui_sidebar <- dashboardSidebar(disable = TRUE
                               # sidebarMenu(
                               #     menuItem("label",
                               #              menuSubItem("label","id",...),
                               #              ...
                               #     )
                               # )
)

#ui_body ------------------------------------------------
ui_body <- dashboardBody(
    tags$head(
        tags$link(rel = "stylesheet", type = "text/css", href = "custom.css")
    ),
    fluidRow(
        box(solidHeader = TRUE, status = "danger",
            title = bootstrapPage(
                div(style= bootstrapStyle,
                    bsButton("settingsModal", "", icon = icon("cog", lib = "glyphicon"),
                             size = "extra-small", type = "action"),
                    bsButton("settingsModal2", "Layout", icon = icon("cog", lib = "glyphicon"),
                             size = "extra-small", type = "action")
                )
            ),
            width = 6, height = "50%"#,
        ),
        box(solidHeader = TRUE, status = "danger",
            title = bootstrapPage(
                div(style= bootstrapStyle,
                    bsButton("settingsModal3", "", icon = icon("cog", lib = "glyphicon"),
                             size = "extra-small", type = "action"),
                    bsButton("settingsModal4", "Layout", icon = icon("cog", lib = "glyphicon"),
                             size = "extra-small", type = "action")
                )
            ),
            width = 6, height = "50%"#,
        )
    ),
    bsModal("mod", "Plot Settings", "settingsModal", size = "small", label = "Plot 1 Settings"),
    bsModal("mod2", "Layout Settings", "settingsModal2", size = "small", label = "Plot 1 Layout"),
    bsModal("mod3", "Plot Settings", "settingsModal3", size = "small", label = "Plot 2 Settings"),
    bsModal("mod4", "Layout Settings", "settingsModal4", size = "small", label = "Plot 2 Layout")
    #modularUI(id, label, ...)
)

ui <- dashboardPage(
    ui_header,
    ui_sidebar,
    ui_body,
    skin = "red"
)


# server ---------------------------------------------------
server <- function(input,output,session){

}

shinyApp(ui,server)



